!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},t=(new e.Error).stack;t&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[t]="46625bd5-bd0d-478a-b71f-186ba315474e",e._sentryDebugIdIdentifier="sentry-dbid-46625bd5-bd0d-478a-b71f-186ba315474e")}catch(e){}}();var _global="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};_global.SENTRY_RELEASE={id:"address-form-page-26.08.20.09.24"},(self.webpackChunk_checkout_android_address_form_page=self.webpackChunk_checkout_android_address_form_page||[]).push([[8021],{8021:(e,t,i)=>{i.r(t),i.d(t,{default:()=>Re});var a,l,r=i(1085),n=i(4041),d=i(3097),s=i(8421),o=i(1661),c=i(4083),f=i(7334),u=i(9072),p=i(5973),h=i(2920),m=i(3018),v=i(624),g=i(9910),A=i(7233),b=i(7829),x=i(1758),E=i(2957);function z(){return z=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var i=arguments[t];for(var a in i)({}).hasOwnProperty.call(i,a)&&(e[a]=i[a])}return e},z.apply(null,arguments)}const k=function(e){return n.createElement("svg",z({xmlns:"http://www.w3.org/2000/svg",width:1e4,height:103,fill:"none",preserveAspectRatio:"xMaxYMid slice",viewBox:"-9672 0 10000 103"},e),a||(a=n.createElement("g",{clipPath:"url(#vaani-card-bg-v2_svg__a)"},n.createElement("path",{fill:"url(#vaani-card-bg-v2_svg__b)",d:"M-9672 0H328v103H-9672z"}),n.createElement("g",{clipPath:"url(#vaani-card-bg-v2_svg__c)"},n.createElement("path",{fill:"#CDEACA",d:"M260.777 81.748s.614-1.238.877-1.72c.263-.48.725-.79 1.503-.501.779.289 8.257 2.926 8.631 3.058.373.13.912.13 1.123-.422.211-.553 1.631-4.063 1.748-4.417.15-.457.123-1.014-.661-1.367-.65-.293-7.283-2.923-7.858-3.096-.577-.174-1.048.077-1.283.567-.236.49-.93 1.856-1.238 2.437-.309.581-.998 1.075-1.692.844-.695-.232-3.429-1.431-3.429-1.431l-2.122 4.298 4.405 1.75zM230.897 35.58l5.83-13.805 35.786 7.786-19.803 13.544-10.9-.556z"}),n.createElement("path",{fill:"#A5D6BD",d:"m267.019 73.63.122 1.563.389-.03-.121-1.564zM272.791 82.54l-2.273-1.464-3.688-1.461.079-.185.521-1.232-1.231-.477c-.367.06-2.604.428-3.875.858-1.419.479-2.305.55-2.342.55l-.03-.39c.009-.001.879-.071 2.247-.532 1.412-.476 3.886-.864 3.99-.881l.052-.008.048.019 1.291.5c.301-.721.581-1.403.621-1.536.106-.358 1.003-1.308 1.699-1.12.635.172 2.553.69 2.992 1.63.375.803-.135 2.413-.343 2.914-.072.177-.114.245-.201.275-.081.03-.136.047-4.556-1.662l-.448 1.06 3.365 1.337 2.29 1.473-.211.33zm-4.844-4.562c1.81.698 3.722 1.429 4.243 1.607.187-.444.653-1.964.352-2.608-.165-.355-.774-.888-2.736-1.418-.436-.117-1.161.627-1.228.852-.046.154-.335.858-.631 1.566"}),n.createElement("path",{fill:"#A5D6BD",d:"m267 79.212-.637 1.495.36.154.637-1.496zM274.397 78.66c-1.478-.138-3.283-.342-3.493-.532-.143-.13-2.233-1.71-3.626-2.757-.559-.087-1.938-.181-2.32.332-.536.718-1.418 2.452-1.427 2.47l-.348-.177c.037-.073.906-1.781 1.462-2.526.605-.812 2.527-.513 2.745-.476l.047.008.038.029c.352.265 3.396 2.554 3.682 2.8.218.106 1.83.307 3.277.443l-.037.39z"}),n.createElement("path",{fill:"#A5D6BD",d:"m271.305 79.425-.358-.156c.092-.213.298-.872.044-1.105l.263-.289c.506.462.1 1.44.051 1.55M270.699 81.073l-.181-.347c.703-.368 1.517-.86 1.606-1.019l.364.142c-.115.31-1.17.9-1.788 1.222zM234.116 34.191l-.111.375 21.791 6.49.111-.375z"}),n.createElement("g",{fill:"#fff"},n.createElement("path",{d:"M404.299 120.944v5.24l-.886-1.29-.675-.978-5.307-7.727-.688-1.001-4.513-6.566-.795-1.157-4.445-6.469-.813-1.183-5.966-8.682-.763-1.11-10.57-15.38-2.017-2.936-1.139-1.656-2.015-2.933-35.756-52.032-1.881-1.12c-.702-.415-1.564-.928-2.573-1.527-22.59-13.43-118.564-70.414-126.715-74.016-10.153-3.933-75.199-11.27-101.334-15.614-2.954-.49-5.412-.944-7.237-1.35l.613-2.906q.05.013.103.022.001.002.008.002c18.24 4.004 98.46 12.69 109.043 17.126 8.638 3.847 104.511 60.785 127.359 74.373 1.002.596 1.862 1.107 2.57 1.53l2.118 1.26 37.234 54.181 2.015 2.93 1.145 1.667 2.017 2.938 5.26 7.654.767 1.117 4.327 6.293.763 1.111 6.203 9.029.813 1.18 8.768 12.76.728 1.06z"}),n.createElement("path",{d:"m404.348 5.98-.05.046v.832l-.565-.299-1.112-.584-49.873-26.286-2.666-1.407-158.555-83.566-146.28-15.279h-190.162l-31.536 82.674-33.401 35.132-2.148-2.05 32.99-34.7 32.055-84.028 192.433.008L192.4-108.18l146.447 77.184 1.503.793 15.944 8.402 20.487 10.798 1.275.672 6.548 3.453q.68.357 1.346.71C392.9-2.509 399.096.757 404.298 3.5v2.427z"}),n.createElement("path",{d:"m280.976 67.068-30.712-22.224 29.941 23.214 2.345 1.82 4.178 3.238 80.133-1.41 3.557-.064 33.88-.596v2.974l-16.982.297-1.456.026-13.425.238-3.557.061-73.682 1.298-1.244.022-8.214.144-5.011-3.885-2.348-1.819L177.558-7.765l1.778-2.38 103.465 74.869 2.407 1.74 3.015 2.183 75.484-1.53 3.551-.071 26.813-.543 1.489-.03 8.738-.178v2.974l-35.025.707-3.551.073-78.432 1.587-3.908-2.827z"}),n.createElement("path",{d:"m399.885-37.464 4.414-1.274v3.093l-1.515.435-3.528 1.019-13.508 3.897-1.354.39-28.098 8.104-3.081.89-.467.6-24.841 31.914-1.837 2.362-40.862 52.497-1.825 2.346-.833 1.068-1.823 2.344-45.205 58.077-51.238 18.943-1.026-2.788 50.445-18.651 44.677-57.4 1.825-2.344.771-.99 1.825-2.344 40.697-52.286 1.839-2.364 24.746-31.791 1.386-1.781 1.036-.3 28.713-8.281 1.564-.452 13.575-3.915zM275.479 19.476 235.594 33.4l.391 1.123 39.885-13.924z"}),n.createElement("path",{d:"m331.136 145.154-70.781-62.825c-.026-.069-22.82-65.17-22.856-65.27l1.119-.395 22.753 64.978 70.55 62.62-.787.89zM359.073 73.226l-42.97 39.547.802.876 42.97-39.547z"}),n.createElement("path",{d:"m337.043 129.538-26.897-41.417 20.302-15.262.712.951-19.415 14.596 26.293 40.484z"}),n.createElement("path",{d:"M404.298 141.853v1.567l-9.294-7.994-.9-.775-19.199-16.518-.908-.78-6.468-5.566-70.953-27.914-2.978-8.979 1.127-.375 2.8 8.45 70.625 27.786 7.599 6.538z"}),n.createElement("path",{d:"m345.267 102.972-8.354-8.444-19.635-11.25 2.126-8.716 1.153.282-1.914 7.846 18.999 10.885 8.468 8.559-.843.836z"}),n.createElement("path",{d:"m327.656 126.855-.746-.924 25.697-20.831 1.81-4.121-25.266-26.311.854-.824 25.816 26.884-2.247 5.113c-.069.056-25.833 20.942-25.92 21.014zM301.36 94.062l-1.159-.251 1.835-8.498 9.399-10.336.876.8-9.183 10.1z"}),n.createElement("path",{d:"m285.458 74.247-.918.753 59.011 72.262.918-.753zM84.957 152.717l-1.703-2.433 54.485-38.29c14.315-2.404 52.854-6.618 67.762-8.205l73.257-31.009a6.58 6.58 0 0 0 4.145-6.566c.013-.025-4.266-122.32-4.254-122.353l2.964-.103 4.252 122.288a9.55 9.55 0 0 1-5.998 9.49l-73.611 31.16c-14.756 1.583-53.275 5.765-67.396 8.141z"}),n.createElement("path",{d:"m276.938 32.224-20.839-4.92-11.773-8.517c-4.837-16.898-5.935-24.007-22.049-35.12l-11.228-17.6 10.805-4.731.474 1.09-9.533 4.172 10.352 16.229c15.798 10.92 17.386 18.115 22.215 35.245L256.6 26.2l20.609 4.866-.273 1.157z"}),n.createElement("path",{d:"m210.307 15.007-.935-.73 20.135-25.83 15.93-7.506.504 1.076-15.673 7.384z"}),n.createElement("path",{d:"m217.991 4.787-.013-1.189 22.135-.267 10.275-7.593.704.957-10.581 7.82z"}),n.createElement("path",{d:"m233.466 3.608-13.971 17.083.918.754 13.97-17.083z"}),n.createElement("path",{d:"M236.941 26.467C224.088 17.35 203.906 3.68 191.155-5.848l.694-.965c12.8 9.564 32.88 23.162 45.777 32.31z"}),n.createElement("path",{d:"m234.124 30.967-.991-.656 6.688-10.154 4.767-2.266.508 1.075-4.467 2.122zM228.097 19.552l-.406-.434c.038-.034 3.682-3.46 4.553-4.957.887-1.528 5.204-10.252 5.248-10.339l.532.264c-.178.36-4.371 8.828-5.266 10.374-.914 1.573-4.507 4.949-4.659 5.093z"}),n.createElement("path",{d:"m269.831 42.269-11.996-2.673c-.126-.133-17.872-18.39-18.006-18.529l-12.142-9.365-10.346-6.596.637-1.002 10.411 6.639 12.231 9.433c.051.045 17.771 18.293 17.818 18.334l11.65 2.596-.257 1.16z"}),n.createElement("path",{d:"m269.81 22.236-1.186.045 1.331 34.702 1.185-.045zM214.918 2.356l-.331.494 3.93 2.644.331-.494zM205.769-1.93l-2.947 3.784.468.365 2.947-3.783zM276.345-4.388l-.293.517 20.843 11.873.293-.517z"}),n.createElement("path",{d:"m285.242 37.202-1.136-.347 6.208-20.41 13.705-18.043.946.72-13.578 17.873-6.144 20.205z"}),n.createElement("path",{d:"m331.74 52.76-33.726-4.904c-.093-.07-20.708-15.654-20.817-15.735l.714-.95 20.574 15.552 33.425 4.86zM300.086 28.643c-.644 0-1.301-.292-1.902-.862-.662-.644-4.232-4.347-4.564-4.69l17.465-19.817 20.912-36.227 1.026.594-20.971 36.33-12.82 14.547 5.711 5.974c-.554.646-2.286 2.867-3.69 3.814a2.23 2.23 0 0 1-1.165.337zm-4.852-5.59c1.356 1.403 3.478 3.59 3.765 3.864.399.378 1.008.75 1.639.37.649-.392 1.968-1.864 2.715-2.74l-4.908-5.135-3.209 3.642z"}),n.createElement("path",{d:"m346.501 40.06-42.066-.414-16.445-14.36.781-.895 16.113 14.07 41.629.41zM304.18 11.996l-.794.883 12.675 11.443.794-.883zM289.426 58.632l-12.102-9.351-7.196-.837.138-1.182 7.521.875 12.363 9.554z"}),n.createElement("path",{d:"m291.824 42.447-8.182 10.987.951.71 8.182-10.986z"}),n.createElement("path",{d:"m297.556 32.943-5.737 10.04.515.295 5.737-10.04zM304.636 24.226l-.401.438 6.786 6.23.4-.439zM357.62 37.705l-6.828-11.376v-.004c-.482-.648-2.193-2.62-3.808-4.424l-20.404-2.5-9.043 3.962-.475-1.09 9.342-4.093 21.167 2.593c2.78 3.081 4.238 4.807 4.396 5.201l6.672 11.117-1.017.612zM330.672 68.06l-1.179-.13 3.093-28.096-15.705-15.521.832-.846 16.117 15.925-.032.286z"}),n.createElement("path",{d:"m339.248 28.473-12.051 1.613.157 1.178 12.051-1.613zM296.066 20.922l-5.029-4.648C282.099 11.083 259.92.909 250.262-3.345l-12.328-35.964 1.122-.386 12.161 35.478c9.745 4.288 31.477 14.281 40.508 19.51l5.144 4.755-.805.874zM220.174 45.925l-.216 1.169 30.326 5.631.216-1.169zM215.253 24.574l-7.95 3.762.253.537 7.95-3.761zM306.563 101.499l-11.871 33.419 1.118.399 11.871-33.42zM267.064 87.444l-9.308-5.973-7.397 4.105-.576-1.04 8.017-4.448 9.905 6.356zM295.818 87.504l-35.832 8.223.265 1.158 35.831-8.222z"})),n.createElement("path",{fill:"#5585F8",d:"M283.959 32C276.802 32 271 37.78 271 44.91c0 3.565 2.591 9.649 6.046 14.838 3.455 5.19 6.91 9.485 6.91 9.485s3.454-4.295 6.91-9.485 6.049-11.272 6.049-14.836c0-7.131-5.801-12.912-12.956-12.912m-.001 18.405c-3.367 0-6.097-2.72-6.097-6.075s2.73-6.074 6.097-6.074 6.096 2.72 6.096 6.074c0 3.355-2.729 6.075-6.096 6.075"})))),l||(l=n.createElement("defs",null,n.createElement("clipPath",{id:"vaani-card-bg-v2_svg__a"},n.createElement("path",{fill:"#fff",d:"M-9672 0H328v103H-9672z"})),n.createElement("clipPath",{id:"vaani-card-bg-v2_svg__c"},n.createElement("path",{fill:"#fff",d:"M-256-200.629h616.348V156H-256z"})),n.createElement("linearGradient",{id:"vaani-card-bg-v2_svg__b",x1:0,x2:0,y1:-31.013,y2:92.538,gradientUnits:"userSpaceOnUse"},n.createElement("stop",{stopColor:"#EAEAF2"}),n.createElement("stop",{offset:1,stopColor:"#fff"})))))};var y,M;function L(){return L=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var i=arguments[t];for(var a in i)({}).hasOwnProperty.call(i,a)&&(e[a]=i[a])}return e},L.apply(null,arguments)}const w=function(e){return n.createElement("svg",L({xmlns:"http://www.w3.org/2000/svg",width:1e4,height:103,fill:"none",preserveAspectRatio:"xMaxYMid slice",viewBox:"-9672 0 10000 103"},e),y||(y=n.createElement("g",{clipPath:"url(#vaani-card-bg-v2-contact_svg__a)"},n.createElement("path",{fill:"url(#vaani-card-bg-v2-contact_svg__b)",d:"M-9672 0H328v103H-9672z"}),n.createElement("g",{clipPath:"url(#vaani-card-bg-v2-contact_svg__c)"},n.createElement("path",{fill:"#CDEACA",d:"M260.777 81.748s.615-1.238.877-1.72c.263-.48.725-.79 1.503-.501.779.289 8.257 2.926 8.631 3.058.374.13.912.13 1.123-.422.211-.553 1.631-4.063 1.748-4.417.151-.457.123-1.014-.661-1.367-.65-.293-7.283-2.923-7.858-3.096-.577-.174-1.048.077-1.283.567-.236.49-.93 1.856-1.238 2.437-.309.581-.998 1.075-1.692.844-.695-.232-3.428-1.431-3.428-1.431l-2.123 4.298 4.405 1.75zM230.897 35.58l5.83-13.805 35.786 7.786-19.803 13.544-10.9-.556z"}),n.createElement("path",{fill:"#A5D6BD",d:"m267.02 73.63.121 1.563.39-.03-.122-1.564zM272.792 82.54l-2.274-1.464-3.688-1.461.079-.185c.122-.288.319-.75.521-1.232l-1.231-.477c-.366.06-2.604.428-3.875.858-1.419.479-2.305.55-2.342.55l-.03-.39c.009-.001.879-.071 2.247-.532 1.412-.476 3.886-.864 3.99-.881l.052-.008.048.019 1.291.5c.301-.721.581-1.403.621-1.536.106-.358 1.003-1.308 1.699-1.12.635.172 2.553.69 2.992 1.63.375.803-.135 2.413-.343 2.914-.072.177-.114.245-.201.275-.081.03-.136.047-4.556-1.662l-.448 1.06 3.365 1.337 2.29 1.473-.21.33zm-4.844-4.562c1.809.698 3.721 1.429 4.242 1.607.187-.444.653-1.964.352-2.608-.165-.355-.774-.888-2.736-1.418-.436-.117-1.161.627-1.228.852-.046.154-.335.858-.631 1.566z"}),n.createElement("path",{fill:"#A5D6BD",d:"m267 79.212-.637 1.495.36.154.637-1.496zM274.397 78.66c-1.478-.138-3.283-.342-3.493-.532-.143-.13-2.233-1.71-3.626-2.757-.559-.087-1.938-.181-2.32.332-.536.718-1.418 2.452-1.427 2.47l-.348-.177c.037-.073.906-1.781 1.462-2.526.605-.812 2.527-.513 2.744-.476l.048.008.038.029c.352.265 3.395 2.554 3.681 2.8.219.106 1.831.307 3.278.443l-.037.39z"}),n.createElement("path",{fill:"#A5D6BD",d:"m271.305 79.425-.358-.156c.092-.213.298-.872.044-1.105l.264-.289c.505.462.099 1.44.05 1.55M270.699 81.073l-.181-.347c.703-.368 1.517-.86 1.606-1.019l.364.142c-.114.31-1.17.9-1.788 1.222zM234.116 34.191l-.111.375 21.791 6.49.111-.375z"}),n.createElement("path",{fill:"#fff",d:"M404.299 120.944v5.24l-.886-1.29-.675-.978-5.307-7.727-.688-1.001-4.513-6.566-.795-1.157-4.445-6.469-.813-1.183-5.966-8.682-.763-1.11-10.57-15.38-2.017-2.936-1.139-1.656-2.015-2.933-35.756-52.032-1.881-1.12c-.702-.415-1.564-.928-2.573-1.527-22.59-13.43-118.564-70.414-126.715-74.016-10.153-3.933-75.199-11.27-101.334-15.614-2.954-.49-5.412-.944-7.237-1.35l.613-2.906q.05.013.103.022.001.002.008.002c18.24 4.004 98.46 12.69 109.043 17.126 8.638 3.847 104.511 60.785 127.359 74.373 1.002.596 1.862 1.107 2.57 1.53l2.118 1.26 37.234 54.181 2.015 2.93 1.145 1.667 2.017 2.938 5.26 7.654.767 1.117 4.327 6.293.763 1.111 6.203 9.029.813 1.18 8.768 12.76.728 1.06z"}),n.createElement("path",{fill:"#fff",d:"m404.348 5.98-.05.046v.832l-.565-.299-1.112-.584-49.873-26.286-2.666-1.407-158.555-83.566-146.28-15.279h-190.162l-31.536 82.674-33.401 35.132-2.148-2.05 32.99-34.7 32.055-84.028 192.433.008L192.4-108.18l146.447 77.184 1.503.793 15.944 8.402 20.487 10.798 1.275.672 6.548 3.453q.68.357 1.346.71C392.9-2.509 399.096.757 404.298 3.5v2.427z"}),n.createElement("path",{fill:"#fff",d:"m280.976 67.068-30.712-22.224 29.941 23.214 2.345 1.82 4.178 3.238 80.133-1.41 3.558-.064 33.88-.596v2.974l-16.983.297-1.455.026-13.425.238-3.558.061-73.682 1.298-1.244.022-8.214.144-5.011-3.885-2.347-1.819L177.559-7.765l1.777-2.38 103.465 74.869 2.407 1.74 3.015 2.183 75.484-1.53 3.552-.071 26.812-.543 1.489-.03 8.739-.178v2.974l-35.025.707-3.552.073-78.432 1.587-3.907-2.827z"}),n.createElement("path",{fill:"#fff",d:"m399.885-37.464 4.414-1.274v3.093l-1.515.435-3.528 1.019-13.508 3.897-1.354.39-28.098 8.104-3.081.89-.467.6-24.841 31.914-1.837 2.362-40.862 52.497-1.825 2.346-.833 1.068-1.823 2.344-45.205 58.077-51.238 18.943-1.026-2.788 50.445-18.651 44.677-57.4 1.825-2.344.771-.99 1.825-2.344 40.697-52.286 1.839-2.364 24.746-31.791 1.386-1.781 1.036-.3 28.713-8.281 1.564-.452 13.575-3.915zM275.48 19.476 235.595 33.4l.39 1.123 39.885-13.924z"}),n.createElement("path",{fill:"#fff",d:"m331.136 145.154-70.781-62.825c-.026-.069-22.82-65.17-22.856-65.27l1.119-.395 22.753 64.978 70.55 62.62-.787.89zM359.072 73.226l-42.969 39.547.802.876 42.97-39.547z"}),n.createElement("path",{fill:"#fff",d:"m337.043 129.538-26.897-41.417 20.302-15.262.712.951-19.415 14.596 26.293 40.484z"}),n.createElement("path",{fill:"#fff",d:"M404.298 141.853v1.567l-9.294-7.994-.9-.775-19.199-16.518-.908-.78-6.468-5.566-70.953-27.914-2.978-8.979 1.127-.375 2.8 8.45 70.625 27.786 7.599 6.538z"}),n.createElement("path",{fill:"#fff",d:"m345.267 102.972-8.354-8.444-19.635-11.25 2.126-8.716 1.153.282-1.914 7.846 18.999 10.885 8.468 8.559-.843.836z"}),n.createElement("path",{fill:"#fff",d:"m327.656 126.855-.746-.924 25.697-20.831 1.81-4.121-25.266-26.311.854-.824 25.816 26.884-2.247 5.113c-.069.056-25.833 20.942-25.92 21.014zM301.36 94.062l-1.159-.251 1.835-8.498 9.399-10.336.876.8-9.183 10.1z"}),n.createElement("path",{fill:"#fff",d:"m285.458 74.247-.918.753 59.011 72.262.918-.753zM84.957 152.717l-1.703-2.433 54.485-38.29c14.315-2.404 52.854-6.618 67.762-8.205l73.257-31.009a6.58 6.58 0 0 0 4.145-6.566c.013-.025-4.266-122.32-4.254-122.353l2.964-.103 4.252 122.288a9.55 9.55 0 0 1-5.998 9.49l-73.611 31.16c-14.756 1.583-53.275 5.765-67.396 8.141z"}),n.createElement("path",{fill:"#fff",d:"m276.938 32.224-20.839-4.92-11.773-8.517c-4.837-16.898-5.935-24.007-22.049-35.12l-11.228-17.6 10.805-4.731.474 1.09-9.533 4.172 10.352 16.229c15.798 10.92 17.386 18.115 22.215 35.245L256.6 26.2l20.609 4.866-.273 1.157z"}),n.createElement("path",{fill:"#fff",d:"m210.307 15.007-.935-.73 20.135-25.83 15.93-7.506.504 1.076-15.673 7.384z"}),n.createElement("path",{fill:"#fff",d:"m217.991 4.787-.013-1.189 22.135-.267 10.275-7.593.704.957-10.581 7.82z"}),n.createElement("path",{fill:"#fff",d:"m233.466 3.608-13.971 17.083.918.754 13.97-17.083z"}),n.createElement("path",{fill:"#fff",d:"M236.941 26.467C224.088 17.35 203.906 3.68 191.155-5.848l.694-.965c12.8 9.564 32.88 23.162 45.777 32.31z"}),n.createElement("path",{fill:"#fff",d:"m234.124 30.967-.991-.656 6.688-10.154 4.767-2.266.508 1.075-4.467 2.122zM228.097 19.552l-.406-.434c.038-.034 3.682-3.46 4.553-4.957.887-1.528 5.204-10.252 5.248-10.339l.532.264c-.178.36-4.371 8.828-5.266 10.374-.914 1.573-4.507 4.949-4.659 5.093z"}),n.createElement("path",{fill:"#fff",d:"m269.831 42.269-11.996-2.673c-.126-.133-17.872-18.39-18.006-18.529l-12.142-9.365-10.346-6.596.637-1.002 10.411 6.639 12.231 9.433c.051.045 17.771 18.293 17.818 18.334l11.65 2.596-.257 1.16z"}),n.createElement("path",{fill:"#fff",d:"m269.81 22.236-1.186.045 1.331 34.702 1.185-.045zM214.918 2.356l-.331.494 3.93 2.644.331-.494zM205.769-1.93l-2.947 3.784.468.365 2.947-3.783zM276.345-4.388l-.293.517 20.843 11.873.293-.517z"}),n.createElement("path",{fill:"#fff",d:"m285.242 37.202-1.136-.347 6.208-20.41 13.705-18.043.946.72-13.578 17.873-6.144 20.205z"}),n.createElement("path",{fill:"#fff",d:"m331.74 52.76-33.726-4.904c-.093-.07-20.708-15.654-20.817-15.735l.714-.95 20.574 15.552 33.425 4.86zM300.086 28.643c-.644 0-1.301-.292-1.902-.862-.662-.644-4.232-4.347-4.564-4.69l17.465-19.817 20.912-36.227 1.026.594-20.971 36.33-12.82 14.547 5.711 5.974c-.554.646-2.286 2.867-3.69 3.814a2.23 2.23 0 0 1-1.165.337zm-4.852-5.59c1.356 1.403 3.478 3.59 3.765 3.864.399.378 1.008.75 1.639.37.649-.392 1.968-1.864 2.715-2.74l-4.908-5.135-3.209 3.642z"}),n.createElement("path",{fill:"#fff",d:"m346.501 40.06-42.066-.414-16.445-14.36.781-.895 16.113 14.07 41.629.41zM304.18 11.996l-.794.883 12.675 11.443.794-.883zM289.426 58.632l-12.102-9.351-7.196-.837.138-1.182 7.521.875 12.363 9.554z"}),n.createElement("path",{fill:"#fff",d:"m291.824 42.447-8.182 10.987.951.71 8.182-10.986z"}),n.createElement("path",{fill:"#fff",d:"m297.556 32.943-5.737 10.04.515.295 5.737-10.04zM304.636 24.226l-.401.438 6.786 6.23.4-.439zM357.62 37.705l-6.828-11.376v-.004c-.482-.648-2.193-2.62-3.808-4.424l-20.404-2.5-9.043 3.962-.475-1.09 9.342-4.093 21.167 2.593c2.78 3.081 4.238 4.807 4.396 5.201l6.672 11.117-1.017.612zM330.672 68.06l-1.179-.13 3.093-28.096-15.705-15.521.832-.846 16.117 15.925-.032.286z"}),n.createElement("path",{fill:"#fff",d:"m339.248 28.473-12.051 1.613.157 1.178 12.051-1.613zM296.066 20.922l-5.029-4.648C282.099 11.083 259.92.909 250.262-3.345l-12.327-35.964 1.121-.386 12.161 35.478c9.745 4.288 31.477 14.281 40.509 19.51l5.143 4.755-.805.874zM220.174 45.925l-.216 1.169 30.326 5.631.216-1.169zM215.253 24.574l-7.95 3.762.253.537 7.95-3.761zM306.563 101.499l-11.871 33.419 1.118.399 11.871-33.42zM267.064 87.444l-9.308-5.973-7.397 4.105-.576-1.04 8.017-4.448 9.905 6.356zM295.818 87.504l-35.832 8.223.265 1.158 35.832-8.222zM279.683 52.166c-.068-.381-.019-.803.048-1.189.053-.236.998-1.527 1.147-1.872.175-.383-.003-.741-.009-1.147-.003-.246.182-.608.176-.816-.016-.507-.121-1.332-.412-1.76-.275-.404-.794-.563-1.209-.797-.194-.107-.402-.254-.599-.344a1.8 1.8 0 0 0-.42-.13c-.665-.12-1.61.12-2.158.484-.574.38-.856 1.028-.972 1.656-.122.663-.025 1.074.018 1.723.018.27-.115.684-.001.977.074.193.2.404.322.576.169.24.319.528.482.762.358.51.588.828.529 1.474-.04.674-.66 1.015-1.243 1.258-.637.264-1.173.588-1.546 1.156-.054.083-.494.74-.305.785.431.103 1.161.066 1.616.065l2.339-.004 3.612.001c.257 0 1.431.059 1.578-.036.212-.514-.629-1.278-1.031-1.551-.631-.43-1.562-.611-1.962-1.271m5.703-4.454c-.195.334-.267.51-.286.903.209.36.397.745.879.836.888.167 2.14.118 3.044.118l3.639-.008c1.267-.043 1.929-.35 1.663-1.667-.174-.15-.466-.412-.708-.436-1.938-.195-3.935-.052-5.886-.093-.263-.005-.54 0-.8.012-.623.026-.985.018-1.545.335m8.058 4.066c-.903-.206-2.846-.072-3.827-.109-.757-.028-3.282-.06-3.857.215-.806.394-.86 1.424-.089 1.818.488.249 1.551.196 2.106.197h4.245c.798-.001 2.27.14 2.379-.923a1.13 1.13 0 0 0-.29-.875.97.97 0 0 0-.667-.323"}),n.createElement("path",{fill:"#5585F8",d:"M273.378 61.627c-.747-.06-2.17.044-2.847-.092a2.1 2.1 0 0 1-1.357-.891c-.5-.739-.375-1.798-.372-2.65l.004-2.602-.001-8.422.002-5.027c-.003-.864-.067-2.008.063-2.844.059-.382.583-1.174.947-1.362.224-.116.748-.311 1.017-.323.809-.037 1.682-.02 2.495-.018h2.287c1.937-.002 2.623-.02 3.544 1.72.096.181.289.395.509.44l.029.006c.556.11 1.421.087 2.011.087l2.482-.002h11.304c.533-.001 1.147-.017 1.672.013 1.144.231 1.856.854 1.901 2.016.042 1.109.015 2.233.015 3.343v6.613l.002 5.468c0 .7-.006 1.402-.003 2.106.004.838-.232 1.584-1.013 2.067-.816.505-1.923.268-2.85.325-.184.01-.491-.017-.658.026l-.038-.013c.238-1.535-.5-2.425-2.196-2.238-.574.064-1.037.399-1.358.834-.084.114-.019.508.007.648-.05.25-.061.536-.081.791-.143-.046-.951-.049-1.133-.049-2.97-.004-5.942-.002-8.913-.005l-2.713.01c-.311 0-.668-.013-.978.003-.067.004-.049.015-.145.007l.002-.03c.144-.86-.044-1.895-1.093-2.142-.968-.228-1.882-.051-2.463.767-.084.12-.02.504.006.648-.026.095-.068.623-.087.772m6.305-9.462c-.068-.381-.019-.803.049-1.189.052-.236.997-1.527 1.146-1.871.175-.384-.003-.742-.009-1.148-.003-.246.182-.608.176-.816-.015-.507-.121-1.332-.411-1.76-.275-.404-.794-.563-1.209-.797-.194-.107-.402-.254-.6-.344a1.8 1.8 0 0 0-.419-.13c-.665-.119-1.61.12-2.159.484-.574.38-.855 1.028-.971 1.656-.123.663-.025 1.074.017 1.723.018.27-.114.684-.001.977.074.193.2.405.322.576.17.24.319.529.483.762.358.51.587.829.529 1.475-.041.673-.661 1.015-1.243 1.257-.638.265-1.173.588-1.546 1.156-.054.083-.494.74-.305.786.43.102 1.16.065 1.615.064l2.34-.004 3.612.001c.257 0 1.43.059 1.577-.036.212-.514-.629-1.278-1.03-1.55-.632-.43-1.562-.612-1.963-1.272m5.703-4.454c-.194.334-.267.51-.286.904.21.36.398.745.879.835.888.167 2.14.118 3.045.118l3.639-.008c1.267-.043 1.928-.35 1.663-1.667-.175-.15-.466-.412-.708-.436-1.938-.195-3.935-.052-5.886-.093-.264-.005-.54 0-.801.012-.623.026-.984.018-1.545.335m8.059 4.066c-.903-.206-2.847-.072-3.827-.108-.758-.03-3.282-.061-3.858.214-.806.394-.86 1.424-.088 1.818.487.249 1.551.196 2.105.197h4.245c.798-.001 2.27.14 2.38-.923a1.13 1.13 0 0 0-.291-.875.97.97 0 0 0-.666-.323"})))),M||(M=n.createElement("defs",null,n.createElement("clipPath",{id:"vaani-card-bg-v2-contact_svg__a"},n.createElement("path",{fill:"#fff",d:"M-9672 0H328v103H-9672z"})),n.createElement("clipPath",{id:"vaani-card-bg-v2-contact_svg__c"},n.createElement("path",{fill:"#fff",d:"M-256-200.629h616.348V156H-256z"})),n.createElement("linearGradient",{id:"vaani-card-bg-v2-contact_svg__b",x1:0,x2:0,y1:-31.013,y2:92.538,gradientUnits:"userSpaceOnUse"},n.createElement("stop",{stopColor:"#EAEAF2"}),n.createElement("stop",{offset:1,stopColor:"#fff"})))))};var F=i(2631),_=i(4385),$=i(916),V=i(9609),j=i(1645),S=i(3697),C=i(8222),I=i(4798),O=i(44),B=i(1993),T=i(7388),D=i(1576),P=i(7308),R=i(6013),N=i(7617),q=i(6878),G=i(8448);const H=(0,n.forwardRef)(({autoFocus:e,placeholderX:t,validatorsX:i,postfix:a,mandatory:l,showTickIconOnBlur:d,scrollOnClick:o},p)=>{const{line1Value:h,line2Value:m,addressLineDisplay:g,fieldTouched:A,shakeOnError:b,backendError:x,setAddressLineDisplay:E,setFocusedField:z,markFieldsShakeOnErrorFields:k}=(0,f.A)(e=>({line1Value:e.fieldsValues.addressLine1,line2Value:e.fieldsValues.addressLine2,addressLineDisplay:e.addressLineDisplay,fieldTouched:e.addressLineTouched,shakeOnError:e.shakeOnErrorFields.addressLine,backendError:e.backendFieldErrors[s.Av.AddressLine],setAddressLineDisplay:e.setAddressLineDisplay,setFocusedField:e.setFocusedField,markFieldsShakeOnErrorFields:e.markFieldsShakeOnErrorFields})),{formMode:y}=(0,u.A)(e=>{var t;return{formMode:null===(t=e.addressInfo)||void 0===t?void 0:t.addressContext}}),{onFocusField:M}=(0,N.A)(),{t:L}=(0,c.A)();(0,P.A)(s.Av.AddressLine);const w=(0,n.useMemo)(()=>(0,D.A)(L).combinedAddressLineValidators,[L]),F=i||w,_=(0,q.SS)({backendError:x,addressLineDisplay:g,addressLine1:h,addressLine2:m,isTouched:A,t:L}),$=null!=g?g:(0,q.QU)(h,m);return(0,n.useEffect)(()=>{if(null!==g)return;const e=(0,q.QU)(h,m);if(!e)return;const{line1:t,line2:i}=(0,q.Li)(h,m,L);if(!t&&!i){G.Q.active=!0;try{E(e,!(0,O.A)(e,F),A,!0)}finally{G.Q.active=!1}}},[g,h,m,A,F,E,L]),(0,r.jsx)(I.A,{width:"100%",children:(0,r.jsx)(R.A,{ref:p,id:s.Av.AddressLine,name:s.Av.AddressLine,type:"text",label:t||L("addressForm.line1.label"),validators:F,onInput:(e,t,i,a)=>{E(t,i,a)},autoFocus:e&&"add"===y,postfix:a,value:$,isTouched:A,onFocus:M,onBlur:(e,t,i,a,l,r,n)=>{E(t,i,a),z(null),k(e,n?!i:b),n&&!i&&(0,v.A)(e,!1),r&&(0,B.A)(e),!i&&a&&l&&(0,T.A)(e,l)},mandatory:l,showTickIconOnBlur:d,shakeOnError:b,externalError:_,scrollOnClick:o})})});var U=i(6122),X=i(9037),Q=i(7332),K=i(794),W=i(379),Y=i(8138),J=i(8590),Z=i(3699),ee=i(4729),te=i(4253),ie=i(7065),ae=i(7195);const le="#ce42ad",re="#e7a0d6",ne="#ffdb3d",de="#941576",se="#f26900",oe=(0,ie.default)(I.A)`
  min-height: 100vh;
  background-color: ${(0,ae.A)("greyT5Subdued")};
  box-shadow: 0 0 0 9999px ${(0,ae.A)("greyT5Subdued")};
`,ce=ie.keyframes`
  from { transform: translate(0, 0); }
  to   { transform: translate(141.421356px, 141.421356px); }
`,fe=ie.css`
  pointer-events: none;
  opacity: ${({$on:e})=>e?1:0};
  transition: opacity ${400}ms ease-in-out;

  &::before {
    animation-play-state: ${({$on:e})=>e?"running":"paused"};
    will-change: ${({$on:e})=>e?"opacity, transform":"auto"};
  }
`,ue=ie.default.div`
  position: absolute;
  inset: 0;
  border-radius: 20px;
  /* Clips the oversized gradient layer to the card silhouette. */
  overflow: hidden;

  &::before {
    content: '';
    position: absolute;
    /* Must exceed the translate distance on every side or the trailing edge of the
       gradient layer slides into view. */
    inset: -220px;
    background: repeating-linear-gradient(
      135deg,
      ${le} 0px,
      ${re} 50px,
      ${ne} 100px,
      ${se} 150px,
      ${le} ${200}px
    );
    animation: ${ce} 3s linear infinite;
  }

  @media (prefers-reduced-motion: reduce) {
    &::before {
      animation: none;
    }
  }

  ${fe}
`,pe=ie.keyframes`
  0%, 100% { opacity: 0.4;  transform: scale(0.99); }
  50%      { opacity: 0.85; transform: scale(1.02); }
`,he=(0,ie.default)(I.A)`
  position: relative;
  width: 100%;
`,me=ie.default.div`
  position: absolute;
  /* A positive inset shrinks the glow source so the halo hugs the card. Never
     negative: blur bleeds outward as ink overflow, but a negative inset is real
     layout and creates a scrollbar. No z-index either — a negative one escapes to the
     root stacking context; source order already puts this behind the opaque card. */
  inset: 10px;
  border-radius: 20px;

  &::before {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: inherit;
    background: linear-gradient(
      135deg,
      ${le},
      ${re},
      ${ne},
      ${se},
      ${le}
    );
    /* Only the feather blur pushes past the card edge is visible. Radius and inset
       are tuned together; much below this and the glow vanishes against the page bg. */
    filter: blur(22px);
    animation: ${pe} 2s ease-in-out infinite;
  }

  @media (prefers-reduced-motion: reduce) {
    &::before {
      animation: none;
      opacity: 0.7;
      transform: none;
    }
  }

  ${fe}
`,ve=(0,ie.default)(I.A)`
  position: relative;
  width: 100%;
  /* The repo ships no box-sizing reset, so width:100% + 32px padding would overflow
     the wrapper and put horizontal scroll on the page. */
  box-sizing: border-box;
  background: white;
  border: 1px solid ${(0,ae.A)("greyT3Divider")};
  border-radius: 20px;
  padding: 32px 16px 16px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  gap: 20px;

  /* Unconditional, not toggled with $glowing: flipping it alongside the colour would
     snap the white fill back under the border the instant the transition ends. */
  background-clip: padding-box;

  /* Cross-fades the border band with GradientRing behind it, so the grey never
     reappears underneath a still-visible gradient. */
  transition: border-color ${400}ms ease-in-out;
  ${({$glowing:e})=>e&&ie.css`
      border-color: transparent;
    `}

  ${({blocked:e})=>e&&ie.css`
      pointer-events: none;
      user-select: none;
    `}
`,ge=(0,ie.default)(I.A)`
  position: absolute;
  top: -1px;
  right: -1px;
  width: 100%;
  height: 103px;
  border-radius: 14px 14px 0 0;
  pointer-events: none;
  overflow: hidden;

  svg {
    display: block;
    width: 100%;
    height: 100%;
  }
`,Ae=(0,ie.default)(I.A)`
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
`,be=(0,ie.default)(I.A)`
  display: flex;
  flex-direction: column;
  gap: 12px;

  /* DOM: this > VaaniHighlight > Box > StyledBox > Box[border], so 3 levels of > div
     reach StyledBox and :first-child inside it is the border Box. */

  /* Error text: Caption2 span after the border Box. */
  & > div > div > div > div:first-child ~ span {
    padding-left: 8px;
  }

  & > div > div > div > div:first-child {
    border-style: solid !important;
    border-width: 1px !important;
    border-color: ${(0,ae.A)("greyT4BG")};
    border-radius: 8px;
    padding-left: 8px !important;
    padding-right: 8px !important;

    label {
      left: 8px !important;
      top: 4px !important;
      /* The label already has overflow:hidden + ellipsis, but those need a bounded
         box. width:auto alone let an absolutely-positioned nowrap label grow to fit,
         so scrollWidth === clientWidth and a long vernac label ran past the field and
         was hard-clipped by FormCard's overflow. Pinning both insets bounds it. */
      right: 8px !important;
      width: auto !important;

      span {
        font-size: 10px !important;
      }
    }
  }
`,xe=1500,Ee=ie.keyframes`
  0% { background-position: 0% 50%; }
  50% { background-position: 100% 50%; }
  100% { background-position: 0% 50%; }
`,ze=ie.keyframes`
  0% { background-position: 0% 0%; }
  50% { background-position: 100% 100%; }
  100% { background-position: 0% 0%; }
`,ke=ie.keyframes`
  0% { opacity: 1; }
  100% { opacity: 0; }
`,ye=(0,ie.default)(I.A)`
  position: relative;

  /* StyledBox — isolate contains the z-index:-1 gradient pseudo here instead of
     letting it escape to the root stacking context and vanish behind the page. */
  & > div > div {
    isolation: isolate;
  }

  /* Box[border] — the actual input container. Wrapping this alone excludes the error
     Caption2 that sits as its sibling. */
  & > div > div > div:first-child {
    position: relative;
    background: white;

    &::before {
      content: '';
      position: absolute;
      inset: -2px;
      border-radius: 10px;
      z-index: -1;
      opacity: 0;
      background: linear-gradient(
        135deg,
        ${le},
        ${re},
        ${ne},
        ${se},
        ${le}
      );
      background-size: 300% 300%;
    }
  }

  ${({phase:e})=>"pulse"===e&&ie.css`
      & > div > div > div:first-child::before {
        opacity: 1;
        animation: ${ze} 3s ease-in-out infinite;
      }
    `}

  /* opacity: 1 is needed because the base ::before has opacity: 0 — without it the
     pseudo snaps invisible before the fade starts. */
  ${({phase:e})=>"fade"===e&&ie.css`
      & > div > div > div:first-child::before {
        opacity: 1;
        animation: ${ke} ${xe}ms ease-in
          forwards;
      }
    `}

  ${({phase:e})=>"pulse"===e&&ie.css`
      input,
      textarea {
        background-image: linear-gradient(
          90deg,
          ${de},
          ${se},
          ${de}
        ) !important;
        background-size: 300% 100% !important;
        -webkit-background-clip: text !important;
        background-clip: text !important;
        -webkit-text-fill-color: transparent !important;
        animation: ${Ee} 1500ms ease-in-out infinite;
      }
    `}

  /* Gradient still pulsing, but text-fill-color transitions transparent → solid,
     smoothly covering it. */
  ${({phase:e})=>"fade"===e&&ie.css`
      input,
      textarea {
        background-image: linear-gradient(
          90deg,
          ${de},
          ${se},
          ${de}
        ) !important;
        background-size: 300% 100% !important;
        -webkit-background-clip: text !important;
        background-clip: text !important;
        -webkit-text-fill-color: #1a1a1a !important;
        transition: -webkit-text-fill-color ${xe}ms ease-in;
        animation: ${Ee} 1500ms ease-in-out infinite;
      }
    `}
`,Me=({onBack:e})=>((0,Y.A)(()=>{(0,h.A)(),e()}),null),Le=(e,t)=>t===s.Av.AddressLine?e.addressLineDisplay:e.fieldsValues[t],we=(e,t)=>t===s.Av.AddressLine?e.addressLineValid:e.fieldsValid[t],Fe=(e,t,i)=>{const a=f.A.getState();e!==s.Av.AddressLine?a.modifyField(e,t,i,!0,!0):a.setAddressLineDisplay(t,i,!0,!0)},_e=({fieldId:e,children:t})=>{const i=(0,f.A)(t=>t.fieldsVaaniFilled[e]),[a,l]=(0,n.useState)(null),d=(0,n.useRef)(null),s=(0,n.useRef)(null),o=(0,n.useRef)(""),c=(0,n.useRef)(!1),u=(0,n.useRef)(!0);(0,n.useEffect)(()=>{if(u.current){u.current=!1;const t=f.A.getState();return o.current=Le(t,e),void(c.current=we(t,e))}if(i>0){const t=i,a=f.A.getState(),r=Le(a,e),n=we(a,e);if(!r)return void l(null);const u=o.current||"";Fe(e,u,c.current);let p=u.length;l("pulse");const h=30*Math.max(0,r.length-p)+3e3+xe;d.current=setInterval(()=>{p++;const t=r.slice(0,p),i=p>=r.length;Fe(e,t,i&&n),i&&(d.current&&clearInterval(d.current),d.current=null,o.current=r,c.current=n,s.current=setTimeout(()=>{s.current=null,l("fade")},3e3))},30);const m=setTimeout(()=>l(null),h);return()=>{const i=!!d.current;d.current&&(clearInterval(d.current),d.current=null),clearTimeout(m),s.current&&(clearTimeout(s.current),s.current=null);const a=f.A.getState().fieldsVaaniFilled[e];i&&a===t&&(Le(f.A.getState(),e)!==r&&Fe(e,r,n),o.current=r,c.current=n)}}d.current&&(clearInterval(d.current),d.current=null),l(null)},[i]);const p=(0,f.A)(t=>Le(t,e));return(0,n.useEffect)(()=>{i||(o.current=p,c.current=we(f.A.getState(),e))},[p,i]),(0,r.jsx)(ye,{phase:a,children:t})},$e={show:!0},Ve=({requiredFields:e,touchField:t,fieldValid:i,combinedAddressValid:a,markFieldsShakeOnErrorFields:l,isManualFlow:r})=>{e.forEach(e=>t(e)),e.includes(s.Av.AddressLine)&&f.A.getState().touchAddressLine();const n=Object.assign(Object.assign({},i),{[s.Av.AddressLine]:a}),d=e.filter(e=>!n[e]),c=(0,J.A)(o.sK.AddressRevampProgressiveVaaniV2,n,r);return(0,m.A)(d),!(d.length>0&&(c&&((0,v.A)(c,!0),l(c,!0)),E.A.error("Please check the errors"),1))},je=e=>{const t=f.A.getState(),{addressLineDisplay:i,fieldsValues:a}=t,l=null!=i?i:(0,q.QU)(a.addressLine1,a.addressLine2);if(!l)return;const{line1:r,line2:n}=(0,q.Li)(a.addressLine1,a.addressLine2,e);if(!(r||n||(0,q.gd)(i,a.addressLine1,a.addressLine2)))return;const d=(0,q.IV)(l,e);if(d){G.Q.active=!0;try{t.modifyField(s.Av.AddressLine1,d.addressLine1,!0,!0,!0),t.modifyField(s.Av.AddressLine2,d.addressLine2,!0,!0,!0)}finally{G.Q.active=!1}t.clearBackendFieldError(s.Av.AddressLine)}},Se=({line1:e,line2:t},i,a)=>{const l=[e&&s.Av.AddressLine1,t&&s.Av.AddressLine2].filter(Boolean),r=e&&t?null:e||t;f.A.getState().setBackendFieldErrors([...i.filter(e=>e.fieldId!==s.Av.AddressLine),{fieldId:s.Av.AddressLine,kind:"CLIENT",reasonCode:r?r.reasonCode:"INCOMPLETE_ADDRESS",severity:"BLOCKING",originFieldIds:l}]),(0,v.A)(s.Av.AddressLine,!0),a(s.Av.AddressLine,!0)},Ce=(e,t,i=!1)=>{const{addressLineDisplay:a,fieldsValues:l,backendFieldErrors:r}=f.A.getState();if((0,q.gd)(a,l.addressLine1,l.addressLine2))return(0,v.A)(s.Av.AddressLine,!0),e(s.Av.AddressLine,!0),E.A.error("Could not verify your address. Please try again"),!1;const n=(0,q.Li)(l.addressLine1,l.addressLine2,t);return!n.line1&&!n.line2||(Se(n,Object.values(r).filter(Boolean),e),i&&E.A.error("Please check your address and try again"),!1)},Ie=(e,t,i)=>{const a=e.errors.filter(e=>"BLOCKING"===e.severity);if(0===a.length&&je(i),e.timedOut)return Ce(t,i);if(a.length>0){const e=a[0].fieldId;return e&&((0,v.A)(e,!0),t(e,!0)),(0,g.A)({outcome:"Blocked",blockReason:"Blocking Error"}),E.A.error("Please check the errors"),!1}const{fieldsValues:l}=f.A.getState(),r=(0,q.Li)(l.addressLine1,l.addressLine2,i);return r.line1||r.line2?(Se(r,e.errors,t),(0,g.A)({outcome:"Blocked",blockReason:"Incomplete Split"}),!1):!(0,q.gd)(f.A.getState().addressLineDisplay,l.addressLine1,l.addressLine2)||((0,v.A)(s.Av.AddressLine,!0),t(s.Av.AddressLine,!0),(0,g.A)({outcome:"Blocked",blockReason:"Stale Split"}),E.A.error("Could not verify your address. Please try again"),!1)},Oe=["pincode","city","state","addressLine1","addressLine2","landmark"],Be=["name","mobile"],Te=[...Be,...Oe],De=({onAddressFilled:e,thinking:t,isValidating:i,requestValidation:a})=>{const l=(0,n.useRef)(null),{t:o}=(0,c.A)(),{pincodeValidators:p,cityValidators:h,canonicalStateValidators:m,combinedAddressLineValidators:v}=(0,D.A)(o),g=(0,f.A)(e=>e.fieldsValid),b=(0,f.A)(e=>e.fieldsTouched),x=(0,f.A)(e=>e.addressLineValid),E=(0,f.A)(e=>e.addressLineTouched),z=(0,f.A)(e=>e.isManualFlow),y=(0,f.A)(e=>e.fieldsSuggestedFromMmi),M=(0,f.A)(e=>e.touchField),L=(0,f.A)(e=>e.markFieldsShakeOnErrorFields),w=(0,f.A)(e=>e.incrementFormSubmissionErrorCount),{editLandmark:F,formMode:S}=(0,u.A)(e=>{var t,i,a;return{editLandmark:null===(i=null===(t=e.addressInfo)||void 0===t?void 0:t.address)||void 0===i?void 0:i.landmark,formMode:null===(a=e.addressInfo)||void 0===a?void 0:a.addressContext}}),[C,I]=(0,n.useState)(!1);(0,n.useEffect)(()=>{var e,t;(0,A.A)(),"add"===S&&(null===(t=null===(e=l.current)||void 0===e?void 0:e.focus)||void 0===t||t.call(e))},[]);const O=(0,n.useCallback)(()=>{const t=[s.Av.AddressLine,s.Av.City,s.Av.State,s.Av.Pincode];Ve({requiredFields:t,touchField:M,fieldValid:g,combinedAddressValid:x,markFieldsShakeOnErrorFields:L,isManualFlow:z})?(I(!0),a(t=>{I(!1),Ie(t,L,o)&&e()})):w()},[g,x,z,e,a,o]),B=t||i&&C;return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsxs)(he,{children:[(0,r.jsx)(me,{$on:B}),(0,r.jsx)(ue,{$on:B}),(0,r.jsxs)(ve,{blocked:t,$glowing:B,children:[(0,r.jsx)(ge,{children:(0,r.jsx)(k,{})}),(0,r.jsxs)(Ae,{children:[(0,r.jsx)(_._J,{color:"greyT2",children:o("addressForm.vaani.v2.stepLabel","1")}),(0,r.jsx)($.ft,{color:"greyBase",children:o("addressForm.vaani.v2.addressStepTitle")})]}),(0,r.jsxs)(be,{children:[(0,r.jsx)(_e,{fieldId:s.Av.AddressLine,children:(0,r.jsx)(H,{ref:l,placeholderX:o("addressForm.line1.label")+"/ "+o("addressForm.line2.label"),validatorsX:v,mandatory:$e,showTickIconOnBlur:x&&E})}),(0,r.jsx)(_e,{fieldId:s.Av.City,children:(0,r.jsx)(X.A,{validatorsX:h,showTickIconOnBlur:g.city&&b.city,mandatory:$e})}),(0,r.jsx)(_e,{fieldId:s.Av.State,children:(0,r.jsx)(j.A,{searchable:!0,validatorsX:m,mandatory:$e,showTickIconOnBlur:g.state&&b.state})}),(0,r.jsx)(_e,{fieldId:s.Av.Pincode,children:(0,r.jsx)(U.A,{scrollOnClick:!0,validatorsX:p,mandatory:$e,showTickIconOnBlur:g.pincode&&b.pincode})}),(F||y.landmark)&&(0,r.jsx)(_e,{fieldId:s.Av.Landmark,children:(0,r.jsx)(Q.A,{})})]})]})]}),"add"===S&&x&&g.city&&g.state&&g.pincode&&(0,r.jsx)(d.Im,{onClick:O,disabled:i||t,block:!0,id:V.fF,children:o("addressForm.footer.cta.saveAddressAndContinue")})]})},Pe=({onSave:e,isEditFlow:t,thinking:i,isValidating:a,requestValidation:l})=>{const{t:o}=(0,c.A)(),{fieldValid:h,fieldTouched:m,fieldsValues:v,addressLineDisplay:g,addressLineValid:A,touchField:x,markFieldsShakeOnErrorFields:z}=(0,f.A)(e=>({fieldValid:e.fieldsValid,fieldTouched:e.fieldsTouched,fieldsValues:e.fieldsValues,addressLineDisplay:e.addressLineDisplay,addressLineValid:e.addressLineValid,touchField:e.touchField,markFieldsShakeOnErrorFields:e.markFieldsShakeOnErrorFields})),{formMode:k,editAddressObject:y}=(0,u.A)(e=>{var t,i;return{formMode:null===(t=e.addressInfo)||void 0===t?void 0:t.addressContext,editAddressObject:null===(i=e.addressInfo)||void 0===i?void 0:i.address}}),{invalidAddressEditFlowType:M}=(0,p.A)(e=>{var t,i;return{invalidAddressEditFlowType:null===(i=null===(t=e.userConfig)||void 0===t?void 0:t.edit_address_flow)||void 0===i?void 0:i.type}}),{nameValidators:L,mobileValidators:F}=(0,D.A)(o),[j,I]=(0,n.useState)(!1);(0,ee.A)();const O=(0,n.useCallback)(()=>{const i=t?[s.Av.Name,s.Av.Mobile,s.Av.Pincode,s.Av.City,s.Av.State,s.Av.AddressLine]:[s.Av.Name,s.Av.Mobile];if(Ve({requiredFields:i,touchField:x,fieldValid:h,combinedAddressValid:A,markFieldsShakeOnErrorFields:z})){if(y&&!y.valid&&"async"===M&&!(g&&g!==(0,q.QU)(y.address_line_1,y.address_line_2)||(0,Z.A)(v,y)))return(0,b.A)(),void E.A.info("Address not valid! Please enter correct address");if(t)I(!0),l(t=>{I(!1),Ie(t,z,o)&&(null==e||e())});else{if(je(o),!Ce(z,o,!0))return;null==e||e()}}},[h,v,g,A,y,M,t,e,l,o]),B=i||a&&j;return(0,r.jsxs)(r.Fragment,{children:["add"===k&&(0,r.jsx)(Me,{onBack:()=>{f.A.getState().setIsNameAndMobileFilled(!1)}}),(0,r.jsxs)(he,{children:[(0,r.jsx)(me,{$on:B}),(0,r.jsx)(ue,{$on:B}),(0,r.jsxs)(ve,{blocked:i,$glowing:B,children:[(0,r.jsx)(ge,{children:(0,r.jsx)(w,{})}),(0,r.jsxs)(Ae,{children:[(0,r.jsx)(_._J,{color:"greyT2",children:o("addressForm.vaani.v2.stepLabel","2")}),(0,r.jsx)($.ft,{color:"greyBase",children:o("addressForm.vaani.v2.contactStepTitle")})]}),(0,r.jsxs)(be,{children:[(0,r.jsx)(_e,{fieldId:s.Av.Name,children:(0,r.jsx)(S.A,{validatorsX:L,mandatory:$e,showTickIconOnBlur:h.name&&m.name})}),(0,r.jsx)(_e,{fieldId:s.Av.Mobile,children:(0,r.jsx)(C.A,{validatorsX:F,mandatory:$e,showTickIconOnBlur:h.mobile&&m.mobile})})]})]})]}),h.name&&h.mobile&&(!t||A&&h.pincode&&h.city&&h.state)&&(0,r.jsx)(d.Im,{onClick:O,disabled:a||i,block:!0,id:V.fF,children:o("addressForm.footer.cta.saveAndContinue")})]})},Re=({onSave:e})=>{const{isNameAndMobileFilled:t,isVaaniThinking:i}=(0,f.A)(e=>({isNameAndMobileFilled:e.isNameAndMobileFilled,isVaaniThinking:e.isVaaniThinking})),{formMode:a,addressLaunchMetadata:l,setIsLocationPermissionGranted:d}=(0,u.A)(e=>{var t;return{formMode:null===(t=e.addressInfo)||void 0===t?void 0:t.addressContext,addressLaunchMetadata:e.addressLaunchMetadata,setIsLocationPermissionGranted:e.setIsLocationPermissionGranted}}),s="edit"===a,o=(0,n.useMemo)(()=>s?Te:t?Be:Oe,[t,s]),c=(0,n.useMemo)(()=>s?"address":t?"contact":"address",[t,s]),{isValidating:p,requestValidation:h}=(0,te.A)({supportedFields:o,scope:c,hasCombinedAddressField:!0,hasCanonicalStateField:!0});(0,W.A)();const{trigger:m}=(0,K.A)();return(0,n.useEffect)(()=>{var e,t;l?l.isLocationPermissionGiven?(d(!0),(0,x.A)(),m()):(d(!1),(0,x.A)()):null===(t=null===(e=null===window||void 0===window?void 0:window.navigator)||void 0===e?void 0:e.geolocation)||void 0===t||t.getCurrentPosition(()=>{d(!0),(0,x.A)()},()=>{d(!1),(0,x.A)()})},[]),(0,r.jsx)(oe,{children:(0,r.jsxs)(F.A,{gap:16,display:"flex",margin:16,children:[(s||!t)&&(0,r.jsx)(De,{onAddressFilled:()=>{f.A.getState().setIsNameAndMobileFilled(!0)},thinking:i,isValidating:p,requestValidation:h}),(s||t)&&(0,r.jsx)(Pe,{onSave:e,isEditFlow:s,thinking:i,isValidating:p,requestValidation:h})]})})}}}]);