!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},t=(new e.Error).stack;t&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[t]="a29fa353-04f3-4731-a613-29bff9402d4c",e._sentryDebugIdIdentifier="sentry-dbid-a29fa353-04f3-4731-a613-29bff9402d4c")}catch(e){}}();var _global="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};_global.SENTRY_RELEASE={id:"pay-later-lite-26.08.26.08.00"},(self.webpackChunk_checkout_android_pay_later_lite=self.webpackChunk_checkout_android_pay_later_lite||[]).push([[658],{9142:(e,t,n)=>{n.d(t,{A:()=>l});var r=n(5608);function l(e){const{fn:t,shouldStopPolling:n,onStop:l,onError:s,interval:i,maxDuration:o,maxRetries:a=3,initialDelay:d=0}=e;let u=null,c=!0;const f=o?Date.now()+o:null,p=(e,t)=>{c&&(c=!1,u&&(clearTimeout(u),u=null),l(e,t))},h=e=>(0,r.sH)(this,void 0,void 0,function*(){var r;if(c){if(f&&Date.now()>f)return p(null);try{const r=yield t(e);if(!c)return;if(n(r))return p(r);u=setTimeout(()=>h(e+1),i)}catch(t){if(!c)return;null==s||s(t,e);const n=null===(r=null==t?void 0:t.response)||void 0===r?void 0:r.status;if("number"==typeof n&&n>=400&&n<500&&e>=a)return p(null,t);u=setTimeout(()=>h(e+1),i)}}});return u=setTimeout(()=>h(1),d),{stop:()=>p(null),isActive:()=>c}}},2877:(e,t,n)=>{n.d(t,{A:()=>o});var r=n(5608),l=n(217),s=n(8475);var i=n(5067);const o=()=>{const e=(0,s.A)(e=>e.applyStageResponse),t=(0,s.A)(e=>e.setLoading),n=(0,s.A)(e=>e.setErrorBottomSheet),o=(0,s.A)(e=>e.currentStage),a=t=>{e(t),i.CM.has(t.process_status)&&n(!0,i.D2[t.process_status])};return{getStage:()=>(0,r.sH)(void 0,void 0,void 0,function*(){t(!0);try{const e=yield(0,l.XC)();return a(e),e}finally{t(!1)}}),submitStage:e=>(0,r.sH)(void 0,void 0,void 0,function*(){if(o){t(!0);try{const t=yield(0,l.pe)(o,e);return a(t),t}finally{t(!1)}}}),applyStageResponse:e,handleStageResponse:a}}},9658:(e,t,n)=>{n.r(t),n.d(t,{default:()=>Y});var r=n(5608),l=n(1085),s=n(4041),i=n(9376),o=n(8986),a=n(2877),d=n(8475),u=n(217),c=n(9142),f=n(5067);var p,h,g=n(9805),x=n(8513),y=n(8969),v=n(1670);function E(){return E=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},E.apply(null,arguments)}const A=function(e){return s.createElement("svg",E({xmlns:"http://www.w3.org/2000/svg",width:18,height:18,fill:"none"},e),p||(p=s.createElement("circle",{cx:8.75,cy:8.75,r:8,fill:"#e7eeff",stroke:"#5585f8",strokeWidth:1.5})),h||(h=s.createElement("path",{fill:"#5585f8",d:"M11.544 5.948a.712.712 0 0 1 .987 1.027l-3.78 3.629v.001l-.845.811a.7.7 0 0 1-.979-.01L4.958 9.438a.712.712 0 0 1 1.007-1.007l1.467 1.466 1.316-1.265h.001z"})))};var b=n(7065),m=n(4385);const S=b.default.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 0.5rem 0;
  width: 100%;
  background: #ffffff;
`,_=b.default.div`
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  width: 100%;
`,I=b.default.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  position: relative;
`,T=b.default.div`
  width: 16px;
  height: 16px;
  border-radius: 100%;
  border: 2px solid ${({$state:e,theme:t})=>"future"===e?t.colors.greyT3Divider:t.colors.blueBase};
  background: ${({$state:e,theme:t})=>"active"===e?t.colors.blueBase:t.colors.white};
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
`,w=(0,b.default)(m._J)`
  color: ${({$active:e,theme:t})=>e?t.colors.white:t.colors.greyT3Divider};
`,R=b.default.div`
  position: absolute;
  left: calc(-50% + 0.5rem);
  right: calc(50% + 0.5rem);
  top: 0.4375rem;
  height: 2px;
  background: ${({$completed:e})=>e?"#5585F8":"#CECEDE"};
`,j=(0,b.default)(m.TR)`
  color: #353543;
  text-align: center;
  margin-top: 0.5rem;
  white-space: pre-line;
`,N=({steps:e})=>{const t=(0,d.A)(e=>e.currentStage),n=e.findIndex(e=>e.stages.includes(t));return(0,l.jsx)(S,{children:(0,l.jsx)(_,{children:e.map((e,t)=>{const r=t<n,s=t===n,i=r?"completed":s?"active":"future";return(0,l.jsxs)(I,{children:[r?(0,l.jsx)(A,{}):(0,l.jsx)(T,{$state:i,children:(0,l.jsx)(w,{$active:s,children:t+1})}),(0,l.jsx)(j,{children:e.stageName}),0!==t&&(0,l.jsx)(R,{$completed:r||s})]},e.stageName)})})})};var O=n(1335);const C=new Set([f.dx.CONSENT,f.dx.BRE_FETCH,f.dx.ASSUREKIT_ELIGIBILITY,f.dx.APPLICATION_APPROVED]),P=new Set([f.dx.BRE_FETCH,f.dx.ASSUREKIT_ELIGIBILITY,f.dx.APPLICATION_APPROVED]),D=(0,s.lazy)(()=>n.e(998).then(n.bind(n,4998))),L=(0,s.lazy)(()=>n.e(450).then(n.bind(n,5450))),k=(0,s.lazy)(()=>n.e(371).then(n.bind(n,4371))),B=(0,s.lazy)(()=>n.e(514).then(n.bind(n,6514))),M=(0,s.lazy)(()=>n.e(107).then(n.bind(n,7107))),$=(0,s.lazy)(()=>n.e(370).then(n.bind(n,2370))),z=(0,s.lazy)(()=>n.e(347).then(n.bind(n,1347))),F=(0,s.lazy)(()=>n.e(25).then(n.bind(n,7025))),H={[f.dx.CONSENT]:D,[f.dx.PERSONAL_INFORMATION]:L,[f.dx.EMPLOYMENT_INFORMATION]:k,[f.dx.INCOME_INFORMATION]:B,[f.dx.BRE_FETCH]:M,[f.dx.ASSUREKIT_ELIGIBILITY]:$,[f.dx.APPLICATION_APPROVED]:z,[f.dx.MANDATE_SETUP]:F},q=()=>{const e=(0,d.A)(e=>e.currentStage),t=(0,d.A)(e=>e.stageDetails),n=(0,d.A)(e=>e.isMandateSetupRequired),r=(0,O.A)(),i=H[e],a=r===f.vI.INDEPENDENT,u=!C.has(e)&&(n||!a),c=!P.has(e),p=f.$F.filter(({stageName:e})=>("Setup Autopay"!==e||n)&&("Place Order"!==e||!a));return(0,l.jsxs)(l.Fragment,{children:[c&&(0,l.jsx)(y.A,{}),u&&(0,l.jsx)(N,{steps:p}),c&&(0,l.jsx)(o.c,{bgColor:"greyT3Divider"}),(0,l.jsx)(s.Suspense,{fallback:null,children:i&&(0,l.jsx)(i,Object.assign({},t))})]})},U=(0,s.lazy)(()=>n.e(998).then(n.bind(n,4998))),Y=()=>{const[e,t]=(0,s.useState)(!1),{handleStageResponse:n}=(0,a.A)();(()=>{const e=(0,d.A)(e=>e.isPollingRequired),t=(0,d.A)(e=>e.setErrorBottomSheet),{handleStageResponse:n}=(0,a.A)(),r=(0,s.useRef)(null),l=(0,s.useRef)(n),i=(0,s.useRef)(t);l.current=n,i.current=t,(0,s.useEffect)(()=>{var t,n;return e?(null===(t=r.current)||void 0===t||t.stop(),r.current=(0,c.A)({fn:()=>(0,u.XC)(),shouldStopPolling:e=>!e.is_polling_required||f.CM.has(e.process_status),onStop:e=>{null!==e&&l.current(e)},onError:()=>{i.current(!0)},interval:5e3})):(null===(n=r.current)||void 0===n||n.stop(),r.current=null),()=>{var e;null===(e=r.current)||void 0===e||e.stop(),r.current=null}},[e])})();const p=(0,d.A)(e=>e.isLoading),h=(0,d.A)(e=>e.showErrorBottomSheet),E=(0,d.A)(e=>e.errorType),A=(0,d.A)(e=>e.setErrorBottomSheet),b=(0,d.A)(e=>e.setMandateSetupRequired),m=v.A.getCurrentScreen()===f.Cy.BOTTOM_SHEET,{search:S}=(0,i.zy)();return(0,s.useEffect)(()=>{const e=new URLSearchParams(S).get("is_mandate_setup_required");null!==e&&b("true"===e)},[]),(0,s.useEffect)(()=>{(0,r.sH)(void 0,void 0,void 0,function*(){try{const e=yield(0,u.XC)();n(e),t(!0)}catch(e){A(!0)}})},[]),h?(0,l.jsx)(x.A,{errorType:E}):p||!e?(0,l.jsx)(g.A,{}):m?(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(y.A,{}),(0,l.jsx)(o.c,{bgColor:"greyT3Divider"}),(0,l.jsx)(s.Suspense,{fallback:null,children:(0,l.jsx)(U,{})})]}):(0,l.jsx)(q,{})}}}]);