!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},o=(new e.Error).stack;o&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[o]="08232186-5704-40fd-925f-6db1e36d1381",e._sentryDebugIdIdentifier="sentry-dbid-08232186-5704-40fd-925f-6db1e36d1381")}catch(e){}}();var _global="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};_global.SENTRY_RELEASE={id:"pay-later-lite-26.08.26.08.00"},(self.webpackChunk_checkout_android_pay_later_lite=self.webpackChunk_checkout_android_pay_later_lite||[]).push([[317],{6505:(e,o,i)=>{"use strict";i.d(o,{K:()=>a,b:()=>d});var t=i(4041),n=i(7065),l=i(2805);const d=e=>{var o;const{isMobile:i,fontFamily:d}=(0,t.useContext)(n.ThemeContext),a=null===(o=null==d?void 0:d.fontWithFallback)||void 0===o?void 0:o.mierFontsBook;return t.createElement(l.E,Object.assign({elm:"span",fontSize:i?"11px":"12px",fontWeight:"book",overrideFontFamily:a,lineHeight:"16px"},e))},a=e=>{var o;const{isMobile:i,fontFamily:d}=(0,t.useContext)(n.ThemeContext),a=null===(o=null==d?void 0:d.fontWithFallback)||void 0===o?void 0:o.mierFontsBook,r=(0,n.default)(l.E)`
    text-transform: uppercase;
  `;return t.createElement(r,Object.assign({elm:"span",fontSize:i?"11px":"12px",fontWeight:"book",overrideFontFamily:a,lineHeight:"16px"},e))}},4895:(e,o,i)=>{"use strict";i.d(o,{Z:()=>r});var t=i(4041),n=i(7065),l=i(6370),d=i(2790);const a=n.default.div.attrs(e=>Object.assign({color:"white"},e))`
  background-color: ${l.lb};
  border-radius: ${({borderRadius:e,theme:{isMobile:o}})=>null!=e?e:o?"0px":"8px"};
  ${d.uC}
  ${d.aG}
  ${d.Iq}
  ${d.OG}
  ${d.JA}
  ${d.r4}
  ${d.pH}
  ${d.zT}
  ${d.lJ}
  ${d.Ep}
  ${d._g}
  ${d.LM}
`,r=e=>t.createElement(a,Object.assign({},e))},5079:(e,o,i)=>{"use strict";i.d(o,{_:()=>N});var t=i(4041),n=i(3144),l=i(9067),d=i.n(l),a=!("undefined"==typeof window||!window.document||!window.document.createElement),r=function(){function e(e,o){for(var i=0;i<o.length;i++){var t=o[i];t.enumerable=t.enumerable||!1,t.configurable=!0,"value"in t&&(t.writable=!0),Object.defineProperty(e,t.key,t)}}return function(o,i,t){return i&&e(o.prototype,i),t&&e(o,t),o}}(),s=function(e){function o(){return function(e,o){if(!(e instanceof o))throw new TypeError("Cannot call a class as a function")}(this,o),function(e,o){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!o||"object"!=typeof o&&"function"!=typeof o?e:o}(this,(o.__proto__||Object.getPrototypeOf(o)).apply(this,arguments))}return function(e,o){if("function"!=typeof o&&null!==o)throw new TypeError("Super expression must either be null or a function, not "+typeof o);e.prototype=Object.create(o&&o.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),o&&(Object.setPrototypeOf?Object.setPrototypeOf(e,o):e.__proto__=o)}(o,e),r(o,[{key:"componentWillUnmount",value:function(){this.defaultNode&&document.body.removeChild(this.defaultNode),this.defaultNode=null}},{key:"render",value:function(){return a?(this.props.node||this.defaultNode||(this.defaultNode=document.createElement("div"),document.body.appendChild(this.defaultNode)),n.createPortal(this.props.children,this.props.node||this.defaultNode)):null}}]),o}(t.Component);s.propTypes={children:d().node.isRequired,node:d().any};const u=s;var v=function(){function e(e,o){for(var i=0;i<o.length;i++){var t=o[i];t.enumerable=t.enumerable||!1,t.configurable=!0,"value"in t&&(t.writable=!0),Object.defineProperty(e,t.key,t)}}return function(o,i,t){return i&&e(o.prototype,i),t&&e(o,t),o}}(),c=function(e){function o(){return function(e,o){if(!(e instanceof o))throw new TypeError("Cannot call a class as a function")}(this,o),function(e,o){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!o||"object"!=typeof o&&"function"!=typeof o?e:o}(this,(o.__proto__||Object.getPrototypeOf(o)).apply(this,arguments))}return function(e,o){if("function"!=typeof o&&null!==o)throw new TypeError("Super expression must either be null or a function, not "+typeof o);e.prototype=Object.create(o&&o.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),o&&(Object.setPrototypeOf?Object.setPrototypeOf(e,o):e.__proto__=o)}(o,e),v(o,[{key:"componentDidMount",value:function(){this.renderPortal()}},{key:"componentDidUpdate",value:function(e){this.renderPortal()}},{key:"componentWillUnmount",value:function(){n.unmountComponentAtNode(this.defaultNode||this.props.node),this.defaultNode&&document.body.removeChild(this.defaultNode),this.defaultNode=null,this.portal=null}},{key:"renderPortal",value:function(e){this.props.node||this.defaultNode||(this.defaultNode=document.createElement("div"),document.body.appendChild(this.defaultNode));var o=this.props.children;"function"==typeof this.props.children.type&&(o=t.cloneElement(this.props.children)),this.portal=n.unstable_renderSubtreeIntoContainer(this,o,this.props.node||this.defaultNode)}},{key:"render",value:function(){return null}}]),o}(t.Component);const w=c;c.propTypes={children:d().node.isRequired,node:d().any};const p=n.createPortal?u:w;var f=i(7065),h=i(8986),g=i(6370),m=i(4895),b=i(6221);const y=e=>t.createElement("svg",Object.assign({width:"20",height:"20",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),t.createElement("path",{d:"M13.7461 2.31408C13.5687 2.113 13.3277 2 13.0765 2C12.8252 2 12.5843 2.113 12.4068 2.31408L6.27783 9.24294C5.90739 9.66174 5.90739 10.3382 6.27783 10.757L12.4068 17.6859C12.7773 18.1047 13.3757 18.1047 13.7461 17.6859C14.1166 17.2671 14.0511 16.5166 13.7461 16.1718L8.29154 9.99462L13.7461 3.82817C13.9684 3.57691 14.1071 2.72213 13.7461 2.31408Z",fill:"#666666"})),C=e=>t.createElement("svg",Object.assign({width:"28",height:"28",viewBox:"0 0 28 28",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),t.createElement("path",{d:"M19.2446 3.23976C18.9961 2.95825 18.6588 2.80005 18.3071 2.80005C17.9553 2.80005 17.618 2.95825 17.3696 3.23976L8.78899 12.9402C8.27037 13.5265 8.27037 14.4736 8.78899 15.0599L17.3696 24.7603C17.8882 25.3466 18.726 25.3466 19.2446 24.7603C19.7632 24.174 19.6716 23.1233 19.2446 22.6406L11.6082 13.9925L19.2446 5.35949C19.5558 5.00772 19.7499 3.81104 19.2446 3.23976Z",fill:"#333333"})),E=e=>t.createElement("svg",Object.assign({width:"100%",height:"100%",viewBox:"0 0 20 20",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),t.createElement("path",{d:"M14.3034 15.7767L10.0124 11.4858L5.70897 15.7892C5.24694 16.2512 4.58159 16.3419 4.11956 15.8799C3.65753 15.4178 3.76954 14.7738 4.23157 14.3117L8.53496 10.0083L4.22267 5.69605C3.76064 5.23402 3.65753 4.58108 4.11956 4.11905C4.58159 3.65702 5.22039 3.77427 5.68243 4.2363L9.99472 8.54859L14.3123 4.23106C14.7743 3.76902 15.4183 3.65702 15.8804 4.11905C16.3424 4.58108 16.2517 5.24643 15.7897 5.70846L11.4721 10.026L15.7631 14.317C16.2251 14.779 16.3424 15.4178 15.8804 15.8799C15.4183 16.3419 14.7654 16.2388 14.3034 15.7767Z",fill:"#666666"})),x=e=>t.createElement("svg",Object.assign({width:"28",height:"28",viewBox:"0 0 28 28",fill:"none",xmlns:"http://www.w3.org/2000/svg"},e),t.createElement("path",{d:"M20.0249 22.0873L14.0175 16.08L7.99276 22.1047C7.34592 22.7516 6.41442 22.8785 5.76758 22.2317C5.12074 21.5849 5.27755 20.6832 5.92439 20.0363L11.9491 14.0116L5.91193 7.97438C5.26509 7.32753 5.12074 6.41341 5.76758 5.76657C6.41442 5.11973 7.30875 5.28388 7.95559 5.93072L13.9928 11.9679L20.0374 5.92338C20.6842 5.27654 21.5859 5.11973 22.2327 5.76657C22.8796 6.41341 22.7526 7.34491 22.1057 7.99175L16.0612 14.0363L22.0686 20.0437C22.7154 20.6905 22.8796 21.5849 22.2327 22.2317C21.5859 22.8785 20.6717 22.7342 20.0249 22.0873Z",fill:"#333333"}));var k=i(8191),O=i(4385);const _=f.default.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
`,S=(0,f.default)(m.Z)`
  flex-direction: column;
`,I=f.default.div`
  display: flex;
  align-items: center;
  max-width: 90%;
`,A=(0,f.default)(b.K0)`
  word-break: break-all;
`,T=({title:e,subtitle:o,showNavArrow:i,handleArrowClick:n,handleClose:l,isPopupHeader:d=!1,hideCloseButton:a=!1,borderRadius:r})=>{const{isMobile:s}=(0,t.useContext)(f.ThemeContext);return t.createElement(S,{block:!0,color:"white",borderRadius:(null!=r?r:s)?"8px 8px 0 0":"none",p:s||d?16:24},t.createElement(_,null,t.createElement(I,null,i&&t.createElement(k.I,{clickable:!0,mr:10,onClick:n,as:s?y:C,iconSize:s?"20":"28"}),t.createElement(A,{pt:d&&a?"4px":0,pb:d&&a?"4px":0,textAlign:"left",color:"greyBase"},e)),!a&&t.createElement(t.Fragment,null,s?t.createElement(k.I,{clickable:!0,iconSize:20,as:E,onClick:l}):t.createElement(k.I,{clickable:!0,iconSize:28,as:x,onClick:l}))),o&&t.createElement(O.M9,{textAlign:"left",color:"greyBase"},o))},L={top:"translateY(-100%)",right:"translateX(100%)",bottom:"translateY(100%)",left:"translateX(-100%)"},$={top:{top:0,right:0,left:0},right:{top:0,right:0,bottom:0},bottom:{right:0,bottom:0,left:0},left:{top:0,bottom:0,left:0}},N=({open:e,title:o,position:i,children:n,handleClose:l,withDivider:d=!0,handleArrowClick:a,showNavArrow:r=!1,subtitle:s,height:u,width:v,hideCloseButton:c})=>{const[w,g]=t.useState(e);t.useEffect(()=>(e&&(document.body.style.overflow="hidden",g(!0)),()=>{document.body.style.overflow="unset"}),[e]);const m=(0,t.useContext)(f.ThemeContext),b=null==m?void 0:m.isMobile;return w?t.createElement(p,null,t.createElement(M,{onClick:()=>l("Outside Tap")}),t.createElement(B,{height:u,isMobile:b,position:i,width:v,open:e,onAnimationEnd:()=>{e||g(!1)}},t.createElement(F,null,t.createElement(P,null,t.createElement(T,{showNavArrow:r,handleArrowClick:a,title:o,handleClose:()=>l("Cross Click"),subtitle:s,hideCloseButton:c}),d&&t.createElement(h.c,null)),n))):null},M=f.default.div`
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 12;
  background: ${g.bf};
  opacity: 0.9;
`,B=f.default.div`
  display: block;
  box-sizing: border-box;
  position: fixed;
  ${e=>$[e.position]};
  z-index: 12;
  max-height: ${({position:e,isMobile:o})=>!o||"bottom"!==e&&"top"!==e?"100%":"90%"};
  height: ${e=>e.height};
  width: 100%;
  max-width: ${({isMobile:e,width:o})=>e?"100%":null!=o?o:"824px"};
  animation: ${e=>{return e.open?(o=e.position,f.keyframes`
0% {transform: ${L[o]} }
100% {transform: translate(0) }
`):(e=>f.keyframes`
0% {transform: translate(0) }
100% {transform: ${L[e]} }
`)(e.position);var o}}
    0.3s ease-in-out;
  overflow-x: hidden;
  overflow-y: auto;
  background-color: ${g.ie};
  border-radius: ${({isMobile:e})=>e?"8px 8px 0 0":"none"};
`,P=f.default.div`
  position: sticky;
  top: 0;
  z-index: 1;
`,F=f.default.div`
  position: relative;
`},9533:(e,o,i)=>{"use strict";i.d(o,{o:()=>c});var t=i(4041),n=i(6370),l=i(7065),d=i(8986);const a=l.css`
  &::after {
    content: '';
    height: 4px;
    width: 4px;
    border-radius: 50%;
    background: ${n.c2};
    position: absolute;
    top: 50%;
    right: 12px;
    transform: translateY(-50%);
  }
`,r=l.css`
  background: ${n.ie};
  color: ${n.c2};
  font-weight: bold; // change this to mier font weight later

  &::before {
    content: '';
    height: 100%;
    background: ${n.c2};
    width: 4px;
    position: absolute;
    top: 0;
    left: 0;
    border-radius: 0px 2px 2px 0px;
  }
`,s=l.default.div`
  display: flex;
  width: 100%;
  position: relative;
  padding: 16px 12px 16px 16px;
  background: #fff;
  color: ${n.zc};
  background: ${n.d9};
  font-size: 13px;

  ${e=>e.filterSelected&&a}

  ${e=>e.active&&r}
`,u=l.css`
  background: #fff;
  color: ${n.c2};

  &::after {
    content: '';
    height: 2px;
    background: ${n.c2};
    width: calc(100% - 32px);
    position: absolute;
    bottom: 0;
    border-radius: 2px 2px 0px 0px;
  }
`,v=l.default.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  padding: 16px 16px;
  font-size: 13px;
  position: relative;
  color: ${e=>e.active?n.c2:n.bf};
  font-weight: ${e=>e.active?"bold":"normal"};

  ${e=>e.active&&u}
`,c=e=>{const o=e.vertical?s:v;return t.createElement(t.Fragment,null,t.createElement(o,{vertical:e.vertical,filterSelected:e.filterSelected,active:e.active,onClick:e.onClick},t.createElement("span",null,e.label)),e.vertical&&t.createElement(d.c,null))};c.defaultProps={active:!1,vertical:!1}},6999:(e,o,i)=>{"use strict";var t=i(6848);function n(){}function l(){}l.resetWarningCache=n,e.exports=function(){function e(e,o,i,n,l,d){if(d!==t){var a=new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");throw a.name="Invariant Violation",a}}function o(){return e}e.isRequired=e;var i={array:e,bigint:e,bool:e,func:e,number:e,object:e,string:e,symbol:e,any:e,arrayOf:o,element:e,elementType:e,instanceOf:o,node:e,objectOf:o,oneOf:o,oneOfType:o,shape:o,exact:o,checkPropTypes:l,resetWarningCache:n};return i.PropTypes=i,i}},9067:(e,o,i)=>{e.exports=i(6999)()},6848:e=>{"use strict";e.exports="SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED"},7591:(e,o,i)=>{"use strict";i.d(o,{A:()=>a});var t=i(5608),n=i(5579),l=i(8155),d=i(7765),a=new class{constructor(){this.navigateOnFailure=()=>{return this.platform===n.i9.IOS?void(null===(t=null===(i=null===(o=null===(e=null===window||void 0===window?void 0:window.webkit)||void 0===e?void 0:e.messageHandlers)||void 0===o?void 0:o.navigateOnFailure)||void 0===i?void 0:i.postMessage)||void 0===t||t.call(i,{message:n.Kl.NAVIGATE_ON_FAILURE,body:{}})):(()=>{var e,o;null===(o=null===(e=null===window||void 0===window?void 0:window.navigate)||void 0===e?void 0:e.navigateOnFailure)||void 0===o||o.call(e)})();var e,o,i,t},this.navigateToBnplAndClose=(e,o)=>this.platform===n.i9.IOS?((e,o)=>{var i,t,l,d;null===(d=null===(l=null===(t=null===(i=null===window||void 0===window?void 0:window.webkit)||void 0===i?void 0:i.messageHandlers)||void 0===t?void 0:t.navigateToBnplAndClose)||void 0===l?void 0:l.postMessage)||void 0===d||d.call(l,{message:n.Kl.NAVIGATE_TO_BNPL_AND_CLOSE,body:{url:e,journey_type:o}})})(e,o):((e,o)=>{var i,t,n;(0,l.OY)(null===(i=null===window||void 0===window?void 0:window.navigate)||void 0===i?void 0:i.navigateToBnplAndClose)&&(null===(n=null===(t=null===window||void 0===window?void 0:window.navigate)||void 0===t?void 0:t.navigateToBnplAndClose)||void 0===n||n.call(t,e,o))})(e,o),this.navigateToBnpl=e=>this.platform===n.i9.IOS?(e=>{var o,i,t,l;null===(l=null===(t=null===(i=null===(o=null===window||void 0===window?void 0:window.webkit)||void 0===o?void 0:o.messageHandlers)||void 0===i?void 0:i.navigateToBnpl)||void 0===t?void 0:t.postMessage)||void 0===l||l.call(t,{message:n.Kl.NAVIGATE_TO_BNPL,body:{url:e}})})(e):(e=>{var o,i;null===(i=null===(o=null===window||void 0===window?void 0:window.navigate)||void 0===o?void 0:o.navigateToBnpl)||void 0===i||i.call(o,e)})(e),this.navigateBack=(e="")=>this.platform===n.i9.IOS?((e="")=>{var o,i,t,l;null===(l=null===(t=null===(i=null===(o=null===window||void 0===window?void 0:window.webkit)||void 0===o?void 0:o.messageHandlers)||void 0===i?void 0:i.navigateBack)||void 0===t?void 0:t.postMessage)||void 0===l||l.call(t,{message:n.Kl.NAVIGATE_BACK,body:{reason:e}})})(e):((e="")=>{var o,i;null===(i=null===(o=null===window||void 0===window?void 0:window.navigate)||void 0===o?void 0:o.navigateBack)||void 0===i||i.call(o,e)})(e),this.navigateOnSuccess=(e,o,i=l.lQ)=>this.platform===n.i9.IOS?((e,o)=>{var i,t,l,d;null===(d=null===(l=null===(t=null===(i=null===window||void 0===window?void 0:window.webkit)||void 0===i?void 0:i.messageHandlers)||void 0===t?void 0:t.navigateOnSuccess)||void 0===l?void 0:l.postMessage)||void 0===d||d.call(l,{message:n.Kl.NAVIGATE_ON_SUCCESS,body:{navigate:e,url:o}})})(e,o):((e,o,i)=>{var t,n,d;(0,l.OY)(null===(t=null===window||void 0===window?void 0:window.navigate)||void 0===t?void 0:t.navigateOnSuccess)?null===(d=null===(n=null===window||void 0===window?void 0:window.navigate)||void 0===n?void 0:n.navigateOnSuccess)||void 0===d||d.call(n,e,o):i()})(e,o,i),this.invokeSmsPermission=()=>{return this.platform===n.i9.IOS?null:void(null===(o=null===(e=null===window||void 0===window?void 0:window.navigate)||void 0===e?void 0:e.invokeSmsPermission)||void 0===o||o.call(e));var e,o},this.getUserLendingConfig=()=>{return this.platform===n.i9.IOS?null:void(null===(o=null===(e=null===window||void 0===window?void 0:window.navigate)||void 0===e?void 0:e.getUserLendingConfig)||void 0===o||o.call(e));var e,o},this.getWebMetaDataAsync=()=>(0,t.sH)(this,void 0,void 0,function*(){return this.platform===n.i9.IOS?(0,t.sH)(void 0,void 0,void 0,function*(){var e,o,i,t;const{resolve:d,promise:a}=(0,l.b$)();return window.getWebMetaData=e=>d(e),null===(t=null===(i=null===(o=null===(e=null===window||void 0===window?void 0:window.webkit)||void 0===e?void 0:e.messageHandlers)||void 0===o?void 0:o.getWebMetaData)||void 0===i?void 0:i.postMessage)||void 0===t||t.call(i,{message:n.Kl.GET_WEB_META_DATA,body:{}}),yield a}):(0,t.sH)(void 0,void 0,void 0,function*(){var e,o,i;return null!==(i=null===(o=null===(e=null===window||void 0===window?void 0:window.webMetaData)||void 0===e?void 0:e.getWebMetaData)||void 0===o?void 0:o.call(e))&&void 0!==i?i:""})}),this.fetchDeviceIdAsync=()=>(0,t.sH)(this,void 0,void 0,function*(){return this.platform===n.i9.IOS?(0,t.sH)(void 0,void 0,void 0,function*(){var e,o,i,t;const{resolve:d,promise:a}=(0,l.b$)();return window.fetchDeviceId=e=>d(e),null===(t=null===(i=null===(o=null===(e=null===window||void 0===window?void 0:window.webkit)||void 0===e?void 0:e.messageHandlers)||void 0===o?void 0:o.fetchDeviceId)||void 0===i?void 0:i.postMessage)||void 0===t||t.call(i,{message:n.Kl.FETCH_DEVICE_ID,body:{message:n.Kl.FETCH_DEVICE_ID}}),yield a}):(0,t.sH)(void 0,void 0,void 0,function*(){var e,o,i;return null!==(i=null===(o=null===(e=null===window||void 0===window?void 0:window.webMetaData)||void 0===e?void 0:e.fetchDeviceId)||void 0===o?void 0:o.call(e))&&void 0!==i?i:""})}),this.captureImage=()=>{return this.platform===n.i9.IOS?void(null===(t=null===(i=null===(o=null===(e=null===window||void 0===window?void 0:window.webkit)||void 0===e?void 0:e.messageHandlers)||void 0===o?void 0:o.captureImage)||void 0===i?void 0:i.postMessage)||void 0===t||t.call(i,{message:n.Kl.CAPTURE_IMAGE,body:{type:"SELFIE"}})):null;var e,o,i,t},this.uploadSelfie=e=>this.platform===n.i9.IOS?null:(e=>{(0,l.wN)()&&(window.uploadSelfie=e)})(e),this.onPageLoaded=()=>{return this.platform===n.i9.IOS?null:void(null===(o=null===(e=null===window||void 0===window?void 0:window.navigate)||void 0===e?void 0:e.onPageLoaded)||void 0===o||o.call(e));var e,o},this.onSmsPermissionStatus=e=>this.platform===n.i9.IOS?null:(e=>{(0,l.wN)()&&(window.onSmsPermissionStatus=e)})(e),this.onCaptureComplete=e=>{(0,l.wN)()&&(window.onCaptureComplete=e)},this.onOtpSmsReceived=e=>this.platform===n.i9.IOS?null:(e=>{var o,i;(0,l.wN)()&&(window.onOtpSmsReceived=e),null===(i=null===(o=null===window||void 0===window?void 0:window.navigate)||void 0===o?void 0:o.startOtpReceiver)||void 0===i||i.call(o)})(e),this.closeWebview=()=>{return this.platform===n.i9.IOS?void((0,l.OY)(null===(i=null===(o=null===(e=null===window||void 0===window?void 0:window.webkit)||void 0===e?void 0:e.messageHandlers)||void 0===o?void 0:o.navigateBack)||void 0===i?void 0:i.postMessage)?null===(a=null===(d=null===(t=null===window||void 0===window?void 0:window.webkit)||void 0===t?void 0:t.messageHandlers)||void 0===d?void 0:d.navigateBack)||void 0===a||a.postMessage({message:n.Kl.NAVIGATE_BACK,body:{}}):(0,l.OY)(null===(u=null===(s=null===(r=null===window||void 0===window?void 0:window.webkit)||void 0===r?void 0:r.messageHandlers)||void 0===s?void 0:s.navigateOnFailure)||void 0===u?void 0:u.postMessage)?null===(w=null===(c=null===(v=null===window||void 0===window?void 0:window.webkit)||void 0===v?void 0:v.messageHandlers)||void 0===c?void 0:c.navigateOnFailure)||void 0===w||w.postMessage({message:n.Kl.NAVIGATE_ON_FAILURE,body:{}}):window.location.href=n.fW):(()=>{var e,o,i,t,d,a;(0,l.OY)(null===(e=null===window||void 0===window?void 0:window.navigate)||void 0===e?void 0:e.navigateBack)?null===(i=null===(o=null===window||void 0===window?void 0:window.navigate)||void 0===o?void 0:o.navigateBack)||void 0===i||i.call(o,"FAILURE"):(0,l.OY)(null===(t=null===window||void 0===window?void 0:window.navigate)||void 0===t?void 0:t.navigateOnFailure)?null===(a=null===(d=null===window||void 0===window?void 0:window.navigate)||void 0===d?void 0:d.navigateOnFailure)||void 0===a||a.call(d):window.location.href=n.fW})();var e,o,i,t,d,a,r,s,u,v,c,w},this.platform=(0,d.uo)()}}}}]);