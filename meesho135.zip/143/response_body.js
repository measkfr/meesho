!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},t=(new e.Error).stack;t&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[t]="e01fb735-24ac-4e02-8f07-bcb7eb4b52fb",e._sentryDebugIdIdentifier="sentry-dbid-e01fb735-24ac-4e02-8f07-bcb7eb4b52fb")}catch(e){}}();var _global="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};_global.SENTRY_RELEASE={id:"pay-later-lite-26.08.26.08.00"},(self.webpackChunk_checkout_android_pay_later_lite=self.webpackChunk_checkout_android_pay_later_lite||[]).push([[448],{4140:(e,t,n)=>{n.d(t,{A:()=>h});var r=n(5608),i=n(5337),o=n(1661),a=n(5973);const s=e=>e&&"object"==typeof e&&!Array.isArray(e),l=(e,...t)=>{if(!t.length)return e;const n=t.shift();if(s(e)&&s(n))for(const t in n)s(n[t])?(e[t]||Object.assign(e,{[t]:{}}),l(e[t],n[t])):Object.assign(e,{[t]:n[t]});return l(e,...t)},d=l;var c=n(2485);const u=n(1756).A.create();var f=n(1165);const p=f.A.API_BASE_URL_NODE_V2&&100*Math.random()<f.A.CHECKOUT_MIGRATION_PERCENTAGE?f.A.API_BASE_URL_NODE_V2:f.A.API_BASE_URL_NODE,g=(e,...t)=>(0,r.sH)(void 0,[e,...t],void 0,function*(e,t={},n=3){var s;try{const n=`${p}/${e}`,s=i.A.getState().authParamsWebview,l=(()=>{var e,t;return(null===(t=null===(e=a.A.getState().userConfig)||void 0===e?void 0:e.vernacular_v2)||void 0===t?void 0:t.selected_language)||o.l7.En})(),c={headers:Object.assign({"meesho-user-context":"logged_in","APP-ISO-LANGUAGE-CODE":l},s)};return yield((e,...t)=>(0,r.sH)(void 0,[e,...t],void 0,function*(e,t={}){const n={headers:{"Content-Type":"application/json"}};try{return(yield u(Object.assign(Object.assign({},d(n,t)),{url:e}))).data}catch(e){throw console.log(e),e}}))(n,d(c,t))}catch(r){if(401===(null===(s=null==r?void 0:r.response)||void 0===s?void 0:s.status)&&n>0)try{const r=yield c.A.refreshAuthParams();return i.A.getState().setAuthParamsWebview(r),g(e,t,n-1)}catch(e){throw r}throw r}}),h=g},2957:(e,t,n)=>{n.d(t,{A:()=>T});var r,i=n(1085),o=n(8191),a=n(7961),s=n(6221),l=n(7065),d=n(4041);function c(){return c=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},c.apply(null,arguments)}const u=function(e){return d.createElement("svg",c({xmlns:"http://www.w3.org/2000/svg",width:16,height:15,fill:"#fff"},e),r||(r=d.createElement("path",{fillRule:"evenodd",d:"M9.731 1.197c-.767-1.344-2.704-1.344-3.472 0L.536 11.207c-.762 1.334.2 2.993 1.736 2.993h11.446c1.536 0 2.498-1.66 1.736-2.992zm-1.737 2.01a1 1 0 0 1 1 1V8.02a1 1 0 0 1-2 0V4.207a1 1 0 0 1 1-1m0 8.501c.456 0 .826-.359.826-.802a.814.814 0 0 0-.826-.802.814.814 0 0 0-.825.802c0 .443.37.802.825.802",clipRule:"evenodd"})))};var f;function p(){return p=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},p.apply(null,arguments)}const g=function(e){return d.createElement("svg",p({xmlns:"http://www.w3.org/2000/svg",width:16,height:16,fill:"none"},e),f||(f=d.createElement("path",{fill:"#fff",fillRule:"evenodd",d:"M0 8c0-4.416 3.584-8 8-8s8 3.584 8 8-3.584 8-8 8-8-3.584-8-8m5.826 3.434a.797.797 0 0 0 1.128 0l6.064-6.072a.797.797 0 1 0-1.128-1.128L6.386 9.738 4.082 7.434a.797.797 0 1 0-1.128 1.128z",clipRule:"evenodd"})))};var h,v;function m(){return m=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},m.apply(null,arguments)}const y=function(e){return d.createElement("svg",m({xmlns:"http://www.w3.org/2000/svg",width:16,height:16,fill:"none"},e),h||(h=d.createElement("g",{clipPath:"url(#warning_svg__a)"},d.createElement("path",{fill:"#fff",fillRule:"evenodd",d:"M8 0C3.584 0 0 3.584 0 8s3.584 8 8 8 8-3.584 8-8-3.584-8-8-8m-.8 4.66a.8.8 0 1 1 1.6 0 .8.8 0 0 1-1.6 0m0 2.414a.8.8 0 0 1 1.6 0v4.266a.8.8 0 0 1-1.6 0z",clipRule:"evenodd"}))),v||(v=d.createElement("defs",null,d.createElement("clipPath",{id:"warning_svg__a"},d.createElement("path",{fill:"#fff",d:"M0 0h16v16H0z"})))))};var A,b;function E(){return E=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var r in n)({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])}return e},E.apply(null,arguments)}const x=function(e){return d.createElement("svg",E({xmlns:"http://www.w3.org/2000/svg",width:16,height:16,fill:"none"},e),A||(A=d.createElement("g",{clipPath:"url(#wishlist-toast_svg__a)"},d.createElement("path",{fill:"#fff",d:"M14.991 8.568a1 1 0 0 0 .104-.152c.144-.208.272-.408.376-.616.008-.016.016-.04.024-.056a4.5 4.5 0 0 0 .289-.736c.063-.208.12-.416.152-.624q.01-.048.008-.096a4 4 0 0 0 .04-.552v-.144c0-.2-.016-.408-.048-.608-.008-.04-.016-.072-.016-.112a5 5 0 0 0-.113-.512c-.008-.04-.024-.088-.032-.128a4 4 0 0 0-.208-.552c-.016-.04-.04-.08-.056-.112a5 5 0 0 0-.24-.448.4.4 0 0 1-.056-.104c-.104-.168-.224-.32-.344-.472-.032-.032-.056-.072-.088-.104a5 5 0 0 0-.352-.368 6.281 6.281 0 0 0-.52-.424c-.04-.024-.08-.056-.112-.08a4 4 0 0 0-.457-.272l-.056-.032a5 5 0 0 0-.528-.224c-.048-.016-.088-.032-.136-.04a5 5 0 0 0-.552-.136c-.008 0-.016 0-.016-.008a3.6 3.6 0 0 0-.585-.048c-.024 0-.048-.008-.072-.008-.04 0-.072.008-.112.008-.064 0-.128.008-.192.008l-.232.024a2 2 0 0 0-.2.032c-.08.016-.16.032-.24.056a3 3 0 0 0-.2.056c-.08.024-.16.056-.24.08l-.192.072c-.08.032-.16.072-.248.112-.064.032-.129.056-.185.096-.088.048-.168.104-.256.152-.056.04-.12.072-.176.112-.096.064-.184.136-.28.208-.048.04-.096.072-.144.112-.136.12-.28.24-.416.384a.1.1 0 0 1-.08.032.1.1 0 0 1-.08-.032 5 5 0 0 0-.416-.376c-.048-.04-.096-.072-.144-.112-.089-.072-.185-.152-.28-.216a2 2 0 0 0-.169-.104c-.088-.056-.168-.112-.256-.16-.064-.032-.128-.064-.184-.088-.08-.04-.168-.08-.248-.12-.064-.032-.128-.048-.192-.072-.08-.032-.16-.056-.248-.088L5.595.928c-.08-.024-.16-.04-.24-.056C5.29.864 5.226.848 5.162.84c-.08-.008-.16-.024-.24-.024C4.858.808 4.794.808 4.73.808 4.69.808 4.65.8 4.61.8c-.024 0-.048.008-.072.008q-.298 0-.584.048c-.008 0-.016 0-.024.008-.184.032-.368.08-.544.136-.048.008-.088.024-.136.04a6 6 0 0 0-.537.216.13.13 0 0 1-.056.032 4 4 0 0 0-.456.272 1 1 0 0 1-.112.08q-.24.166-.456.368c-.016.016-.04.04-.064.056a4 4 0 0 0-.36.384c-.024.032-.056.064-.08.096-.129.152-.24.312-.345.472-.024.032-.04.064-.064.096q-.13.228-.248.456c-.016.04-.032.072-.048.112-.08.184-.152.368-.208.56-.016.04-.024.08-.04.12a4 4 0 0 0-.112.512c-.008.04-.016.072-.016.112-.032.192-.048.4-.048.6v.144c0 .184.016.376.048.56 0 .032.008.056.008.088.032.208.088.416.152.632l.048.144c.072.2.144.392.248.592a.4.4 0 0 1 .024.056c.104.208.232.416.376.616.032.048.072.096.104.152.153.208.32.408.505.608l5.242 5.488c.168.176.368.312.576.4q.337.134.673.136c.224 0 .448-.048.656-.136s.408-.224.576-.4l5.243-5.488q.286-.298.512-.608"}))),b||(b=d.createElement("defs",null,d.createElement("clipPath",{id:"wishlist-toast_svg__a"},d.createElement("path",{fill:"#fff",d:"M0 .8h16v14.4H0z"})))))},w=(0,l.default)(s.Db)`
  width: 100%;
`,_=(0,l.default)(o.I)`
  min-width: 16px;
`,O={},j=(e,t,n=!1,r={})=>{if(O[t])return;const o=Object.assign({position:"bottom-center",duration:3e3,style:{padding:"5px 10px",width:"100%",maxWidth:"800px",color:"white"}},r),s=(n?a.Ay.error:a.Ay.success)((0,i.jsx)(w,{color:"white",children:t}),Object.assign(Object.assign({},o),{icon:(0,i.jsx)(_,{as:e,iconSize:16})}));O[t]=!0,window.setTimeout(()=>{O[t]=!1,a.Ay.dismiss(s)},o.duration||3e3)},T={success:e=>{j(g,e,!1,{style:{backgroundColor:"#038D63"}})},error:(e="Unexpected error. Please try again")=>{j(u,e,!0,{style:{backgroundColor:"#E11900"}})},info:e=>{j(y,e,!1,{style:{backgroundColor:"#353543"},duration:4e3})},infoSuccess:e=>{j(g,e,!1,{style:{backgroundColor:"#353543"},duration:4e3})},wishlistSuccess:e=>{j(x,e,!1,{style:{backgroundColor:"#353543"},duration:4e3})},customToast:(e,t={})=>{const n=Object.assign({position:"bottom-center",duration:3e3,style:{width:"100%",maxWidth:"800px",color:"white"}},t),r=(0,a.Ay)(e,Object.assign({},n));O[JSON.stringify(e)]=!0,window.setTimeout(()=>{O[JSON.stringify(e)]=!1,a.Ay.dismiss(r)},n.duration||3e3)}}},6697:(e,t,n)=>{n.d(t,{h:()=>o,p:()=>a});var r=n(4798),i=n(7065);const o=(0,i.default)(r.A)`
  display: flex;
  flex-direction: column;
  width: 100%;
  height: 100vh;
  background: #ffffff;
`,a=(0,i.default)(r.A)`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 0 1.25rem;
  gap: 0.5rem;
  text-align: center;
`},9805:(e,t,n)=>{n.d(t,{A:()=>u});var r=n(1085),i=n(916),o=n(8285),a=n(8986),s=n(8475),l=n(8969),d=n(8251),c=n(6697);const u=e=>{const{title:t}=e,n=(0,s.A)(e=>e.setLoading);return(0,r.jsxs)(c.h,{children:[(0,r.jsx)(l.A,{title:t}),(0,r.jsx)(a.c,{bgColor:"greyT3Divider"}),(0,r.jsxs)(c.p,{children:[(0,r.jsx)(d.A,{onComplete:()=>n(!1)}),(0,r.jsx)(i.ft,{mt:"2rem",color:"greyBase",children:"Loading, please wait.."}),(0,r.jsx)(o.Sv,{mt:"0.5rem",color:"greyT1",children:"Please do not close or go back. This might take few seconds"})]})]})}},8251:(e,t,n)=>{n.d(t,{A:()=>u});var r=n(1085),i=n(4041),o=n(4838),a=n(2167),s=n(7065);const l=s.default.div`
  position: relative;
  width: 7.5rem;
  height: 7.5rem;
`,d=s.default.div`
  position: absolute;
  top: ${({offset:e})=>e}px;
  left: ${({offset:e})=>e}px;
  z-index: 4;
`,c=(0,i.lazy)(()=>n.e(495).then(n.bind(n,4495))),u=({duration:e=a.L0,onComplete:t,showCircularProgress:n=!0})=>{const[s,u]=(0,i.useState)(0);return(0,i.useEffect)(()=>{const n=Date.now(),r=window.setInterval(()=>{const i=Date.now()-n,o=Math.min(i/e*100,100);u(o),o>=100&&(window.clearInterval(r),null==t||t())},50);return()=>window.clearInterval(r)},[e,t]),(0,r.jsxs)(l,{children:[n&&(0,r.jsx)(o.A,{size:120,strokeWidth:4,percentage:s}),(0,r.jsx)(d,{offset:30,children:(0,r.jsx)(i.Suspense,{fallback:null,children:(0,r.jsx)(c,{path:a.xH,loop:!0,play:!0,style:{width:60}})})})]})}},7430:(e,t,n)=>{n.d(t,{N:()=>i,Q:()=>r});const r={GET_USER_ELIGIBILITY:"api/v1/user/user-details",GET_STAGE:"api/v1/user/stage",SUBMIT_STAGE:"api/v1/user/stage",SEND_OTP:"api/v1/otp/send",VERIFY_OTP:"api/v1/otp/verify",GET_REPAYMENT_SUMMARY:"api/v1/repayments/summary",GET_PENDING_REPAYMENTS:"api/v1/repayments/open",GET_REPAYMENT_HISTORY:"api/v1/repayments/history",LIST_PAYMENT_OPTIONS:"api/v1/list/payment-options",INITIATE_REPAYMENT:"api/v1/repayments/initiate",MANDATE_INITIATE:"api/v1/mandate/initiate",MANDATE_STATUS:"api/v1/mandate/status"},i=e=>`api/v1/repayments/${e}/status`},2167:(e,t,n)=>{n.d(t,{L0:()=>o,c:()=>s,eQ:()=>l,of:()=>a,xH:()=>i});const r="https://static.meeshosupply.com/supplier-new",i="https://static.mppl.meesho.com/assets/loader-animation.json",o=3e4,a=`${r}/autopay-horizontal.png`,s=`${r}/autopay-vertical.png`,l=`${r}/upi-circle.png`},652:(e,t,n)=>{n.d(t,{E:()=>r});const r=(e,t=0)=>`${e<0?"-":""}₹${Math.abs(e).toLocaleString("hi-IN",{minimumFractionDigits:t,maximumFractionDigits:t})}`},5183:(e,t,n)=>{n.d(t,{A:()=>i});var r=n(4041);const i=e=>{const[t,n]=(0,r.useState)(e);return[t,(0,r.useCallback)(e=>{n(t=>Object.assign(Object.assign({},t),e))},[n])]}},3448:(e,t,n)=>{n.r(t),n.d(t,{default:()=>F});var r=n(5608),i=n(1085),o=n(4041),a=n(478),s=n(2957),l=n(8986),d=n(8969),c=n(9805),u=n(5183),f=n(7065),p=n(4798),g=n(916),h=n(4385),v=n(3097);const m=(0,f.default)(p.A)`
  display: flex;
  flex-direction: column;
  background: #ffffff;
`,y=(0,f.default)(p.A)`
  padding: 1.5rem 1rem;
  display: flex;
  flex-direction: column;
  gap: 2rem;
`,A=(0,f.default)(p.A)`
  display: flex;
  flex-direction: column;
  gap: 1.25rem;
`,b=(0,f.default)(p.A)`
  display: flex;
  flex-direction: column;
  gap: 2rem;
`,E=(0,f.default)(g.ft)`
  color: #353543;
`,x=(0,f.default)(p.A)`
  display: flex;
  gap: 1rem;
  align-items: flex-start;
`,w=(0,f.default)(p.A)`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 3px;
`,_=f.default.input`
  width: 100%;
  text-align: center;
  font-family: inherit;
  font-size: 17px;
  font-weight: 700;
  line-height: 20px;
  color: #353543;
  background: transparent;
  border: none;
  outline: none;
  padding: 0;
  caret-color: #9f2089;
`,O=f.default.div`
  width: 100%;
  height: 1px;
  background: ${({$filled:e})=>e?"#353543":"#cecede"};
`,j=(0,f.default)(h.M9)`
  color: #e02020;
`,T=(0,f.default)(h.TR)`
  color: #8b8ba3;
`,P=f.default.span`
  color: #9f2089;
  cursor: pointer;
`,S=f.default.div`
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  background: #ffffff;
  border-top: 1px solid #cecede;
`,I=(0,f.default)(g.ft)`
  color: #353543;
`,R=(0,f.default)(v.Im)`
  min-width: 160px;
`,N=({phoneNumber:e,orderAmount:t,onPlaceOrder:n,onResendOtp:r,isLoading:a=!1,resendIntervalSeconds:s=60,resendEnabled:l=!1,errorMessage:d,autoFilledOtp:c})=>{const f=(0,o.useRef)([]),[p,g]=(0,u.A)({otp:Array(6).fill(""),resendSeconds:s,isResendActive:!1}),{otp:h,resendSeconds:v,isResendActive:N}=p;(0,o.useEffect)(()=>{l&&g({isResendActive:!0,resendSeconds:0})},[l,g]),(0,o.useEffect)(()=>{var e;d&&(g({otp:Array(6).fill("")}),null===(e=f.current[0])||void 0===e||e.focus())},[d,g]),(0,o.useEffect)(()=>{if(!c)return;const e=c.slice(0,6).split("");g({otp:[...e,...Array(6-e.length).fill("")]})},[c,g]),(0,o.useEffect)(()=>{let e;return v>0?e=setTimeout(()=>g({resendSeconds:v-1}),1e3):g({isResendActive:!0}),()=>clearTimeout(e)},[v,g]);const C=h.every(Boolean);return(0,i.jsxs)(m,{children:[(0,i.jsx)(y,{children:(0,i.jsxs)(A,{children:[(0,i.jsxs)(b,{children:[(0,i.jsxs)(E,{children:["Enter OTP sent to ",e]}),(0,i.jsx)(x,{children:h.map((e,t)=>(0,i.jsxs)(w,{children:[(0,i.jsx)(_,{ref:e=>{f.current[t]=e},type:"tel",inputMode:"numeric",maxLength:1,value:e,onChange:e=>((e,t)=>{var n;const r=t.replace(/\D/g,"").slice(-1),i=[...h];i[e]=r,g({otp:i}),r&&e<5&&(null===(n=f.current[e+1])||void 0===n||n.focus())})(t,e.target.value),onKeyDown:e=>((e,t)=>{var n;"Backspace"===t.key&&!h[e]&&e>0&&(null===(n=f.current[e-1])||void 0===n||n.focus())})(t,e),autoComplete:"one-time-code","aria-label":`OTP digit ${t+1}`}),(0,i.jsx)(O,{$filled:!!e})]},t))})]}),d&&(0,i.jsx)(j,{children:d}),N?(0,i.jsx)(T,{children:(0,i.jsx)(P,{onClick:()=>{var e;N&&(g({otp:Array(6).fill(""),resendSeconds:s,isResendActive:!1}),null==r||r(),null===(e=f.current[0])||void 0===e||e.focus())},children:"Resend OTP"})}):(0,i.jsxs)(T,{children:["Resend OTP in ",v," s"]})]})}),(0,i.jsxs)(S,{children:[(0,i.jsx)(I,{children:t}),(0,i.jsx)(R,{onClick:()=>C&&n(h.join("")),disabled:!C||a,children:"Place Order"})]})]})};var C=n(4140),D=n(7430);const M=(e,t)=>(0,C.A)(D.Q.SEND_OTP,{method:"POST",data:{user_id:Number(e),order_num:t}});var L=n(1670),k=n(652);const F=()=>{const[e,t]=(0,u.A)({orderId:"",phoneNumber:"",orderAmount:0,isVerifying:!1,isLoading:!0,otpSendFailed:!1,otpErrorMessage:"",autoFilledOtp:""}),{orderId:n,phoneNumber:f,orderAmount:p,isVerifying:g,isLoading:h,otpSendFailed:v,otpErrorMessage:m,autoFilledOtp:y}=e;return(0,o.useEffect)(()=>{(0,r.sH)(void 0,void 0,void 0,function*(){var e,n;try{const e=L.A.getWebMetaData(),n=JSON.parse(null!=e?e:"{}");t({orderId:n.order_num,orderAmount:n.amount}),L.A.onSmsReceived(e=>{const n=(e=>{var t;if("string"!=typeof e)return null;const n=e.match(/\b\d{4,6}\b/);if(n)return n[0];const r=null===(t=e.split(" "))||void 0===t?void 0:t[5];return Number(r)?r:null})(e);n&&t({autoFilledOtp:n})}),window.onSmsFetchFailed=()=>{};const r=yield M((0,a.A)(),n.order_num);t({isLoading:!1,phoneNumber:r.phone_number})}catch(r){"OTP_NOT_ALLOWED"===(null===(n=null===(e=null==r?void 0:r.response)||void 0===e?void 0:e.data)||void 0===n?void 0:n.code)?t({isLoading:!1}):(t({isLoading:!1,otpSendFailed:!0}),s.A.error("Could not send OTP. Please try again."))}})},[]),h?(0,i.jsx)(c.A,{title:"PLACE ORDER"}):(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(d.A,{title:"PLACE ORDER"}),(0,i.jsx)(l.c,{bgColor:"greyT3Divider"}),(0,i.jsx)(N,{phoneNumber:f||"your phone number",orderAmount:(0,k.E)(p),onPlaceOrder:e=>(0,r.sH)(void 0,void 0,void 0,function*(){var r,i,o;t({isVerifying:!0,otpErrorMessage:""});try{const s=yield((e,t,n)=>(0,C.A)(D.Q.VERIFY_OTP,{method:"POST",data:{user_id:Number(e),order_num:t,otp:n}}))((0,a.A)(),n,e);if(s.is_verified)return void L.A.transactionComplete("success");const l=null===(r=s.error)||void 0===r?void 0:r.code;"OTP_ATTEMPTS_EXCEEDED"===l||"OTP_EXPIRED"===l?L.A.transactionComplete("failure"):t({otpErrorMessage:null!==(o=null===(i=s.error)||void 0===i?void 0:i.message)&&void 0!==o?o:"Incorrect OTP. Please try again."})}catch(e){s.A.error("OTP verification failed. Please try again.")}finally{t({isVerifying:!1})}}),onResendOtp:()=>(0,r.sH)(void 0,void 0,void 0,function*(){t({otpSendFailed:!1});try{yield M((0,a.A)(),n)}catch(e){t({otpSendFailed:!0}),s.A.error("Could not resend OTP. Please try again.")}}),isLoading:g,resendEnabled:v,errorMessage:m,autoFilledOtp:y})]})}},478:(e,t,n)=>{n.d(t,{A:()=>i});var r=n(5337);const i=()=>r.A.getState().authParamsWebview["APP-USER-ID"]}}]);