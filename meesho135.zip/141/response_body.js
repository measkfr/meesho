!function(){try{var e="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{},t=(new e.Error).stack;t&&(e._sentryDebugIds=e._sentryDebugIds||{},e._sentryDebugIds[t]="c8207e02-8340-49fc-8941-31c1a2d179de",e._sentryDebugIdIdentifier="sentry-dbid-c8207e02-8340-49fc-8941-31c1a2d179de")}catch(e){}}();var _global="undefined"!=typeof window?window:"undefined"!=typeof global?global:"undefined"!=typeof self?self:{};_global.SENTRY_RELEASE={id:"pay-later-lite-26.08.26.08.00"},(self.webpackChunk_checkout_android_pay_later_lite=self.webpackChunk_checkout_android_pay_later_lite||[]).push([[577],{4593:(e,t,r)=>{r.d(t,{A:()=>g});var n=r(1085),i=r(4041),l=r(3097),o=r(2631),d=r(5067),s=r(5608),a=r(7065),c=r(4798);const u=a.keyframes`
    from { transform: translateX(0); }
    to   { transform: translateX(-100%); }
`,f=a.keyframes`
    from { transform: translateX(0); }
    to   { transform: translateX(100%); }
`,h=(0,a.default)(l.Im)`
    position: relative;
    overflow: hidden;
    width: 100%;
`,m=(0,a.default)(c.A)`
    animation: ${({$reverse:e})=>e?f:u} ${({$duration:e})=>e}s linear 1;
    animation-fill-mode: forwards;
    position: absolute;
    z-index: 10;
    background: rgba(255, 255, 255, 0.6);
    top: 0;
    bottom: 0;
    width: 100%;
    left: ${({$reverse:e})=>e?"0%":"100%"};
`,x=e=>{var{duration:t=d.V0,reverse:r,children:l,onClick:o}=e,a=(0,s.Tt)(e,["duration","reverse","children","onClick"]);const c=(0,i.useRef)(o);return c.current=o,(0,i.useEffect)(()=>{const e=setTimeout(()=>{var e;return null===(e=c.current)||void 0===e?void 0:e.call(c,{})},1e3*t);return()=>clearTimeout(e)},[t]),(0,n.jsxs)(h,Object.assign({},a,{onClick:o,children:[l,(0,n.jsx)(m,{$reverse:r,$duration:t})]}))},g=e=>{const{ctaText:t,disabled:r,children:i,isTimerButton:s,onAction:a}=e;return(0,n.jsxs)(o.A,{position:"fixed",bottom:"0",width:"100%",padding:"0.75rem 1rem 1rem",zIndex:13,children:[i,s?(0,n.jsx)(x,{block:!0,onClick:a,duration:d.V0,children:t}):(0,n.jsx)(l.Im,{style:{flex:1},disabled:r,onClick:a,block:!0,children:t})]})}},8513:(e,t,r)=>{r.d(t,{A:()=>p});var n=r(1085),i=(r(4041),r(7591)),l=r(916),o=r(8285),d=r(2631),s=r(5067),a=r(6407),c=r(4593),u=r(7065),f=r(4798);const h=u.default.div`
  display: flex;
  flex-direction: column;
  min-height: 100vh;
`,m=(0,u.default)(f.A)`
  display: flex;
  flex-direction: row;
  padding: 0.75rem 1rem;
  gap: 0.25rem;
  justify-content: flex-start;
  align-items: center;
  width: 100%;
`,x=(0,u.default)(d.A)`
  background: linear-gradient(180deg, #FFE7FB 0%, #FFFFFF 98.77%);
  flex: 1;
  gap: 2rem;
  padding: 3.75rem 0 6rem;
`,g=(0,u.default)(l.ft)`
  max-width: 15rem;
  text-align: center;
`,p=({errorType:e})=>{var t;const{heading:r,subtext:u,Illustration:f}=null!==(t=e&&s.m[e])&&void 0!==t?t:s.U4;return(0,n.jsxs)(h,{children:[(0,n.jsxs)(m,{children:[(0,n.jsx)(a.A,{}),(0,n.jsx)(l.ft,{color:"greyBase",children:"Meesho Pay Later LITE"})]}),(0,n.jsxs)(x,{alignItems:"center",children:[(0,n.jsx)(f,{}),(0,n.jsxs)(d.A,{gap:"0.5rem",alignItems:"center",children:[(0,n.jsx)(g,{color:"greyBase",children:r}),(0,n.jsx)(o.Sv,{color:"greyT1",children:u})]})]}),(0,n.jsx)(c.A,{ctaText:"Going Back",onAction:()=>{null===i.A||void 0===i.A||i.A.closeWebview()},isTimerButton:!0})]})}},5577:(e,t,r)=>{r.r(t),r.d(t,{default:()=>f});var n=r(1085),i=r(4041),l=r(9376),o=r(2631),d=r(5628),s=r(8969),a=r(8513);const c=e=>{if(!e)return!1;try{return"https:"===new URL(e).protocol}catch(e){return!1}},u=(0,i.lazy)(()=>Promise.all([r.e(669),r.e(361)]).then(r.bind(r,7361))),f=()=>{const[e]=(0,l.ok)(),t=e.get("document_link"),r=e.get("iframe_src"),f=c(t)?t:null,h=c(r)?r:null,m=!!t&&!f||!!r&&!h;return(0,n.jsxs)(o.A,{height:"100vh",overflow:"hidden",children:[(0,n.jsx)(s.A,{title:"Terms & Conditions"}),(0,n.jsx)(o.A,{height:"calc(100vh - 56px)",overflowY:"auto",width:"100%",children:(()=>{if(m||!f&&!h)return(0,n.jsx)(a.A,{});const e=null!=f?f:null!==(r=null==(t=h)?void 0:t.toLowerCase().endsWith(".pdf"))&&void 0!==r&&r?h:null;var t,r;return e?(0,n.jsx)(i.Suspense,{fallback:(0,n.jsx)(o.A,{width:"100%",height:"calc(100vh - 56px)",children:(0,n.jsx)(d.A,{})}),children:(0,n.jsx)(u,{documentLink:e})}):(0,n.jsx)("iframe",{src:h,title:"Document Preview",style:{width:"100%",height:"calc(100vh - 56px)",border:"none",display:"block"}})})()})]})}}}]);